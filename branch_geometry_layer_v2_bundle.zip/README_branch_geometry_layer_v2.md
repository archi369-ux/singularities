
# Branch Geometry Layer v2

This bundle upgrades the branch metric/tensor layer with:

- branch-aware Christoffel symbol shell
- numeric fixed-guard Christoffel evaluation
- numeric Riemann, Ricci, and scalar curvature in 2D
- geodesic acceleration computed from Christoffel symbols

## Scope

This is still a prototype:
- 2D charts only
- fixed-guard numeric derivatives
- no full symbolic tensor algebra for curvature yet

## Charts included

- ingoing Eddington–Finkelstein 2D
- Schwarzschild t-r 2D

## Run

```bash
python branch_geometry_layer_v2.py
```
