
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple, Union
import math


# ============================================================
# Guard / branch basics
# ============================================================

@dataclass(frozen=True)
class Guard:
    atoms: Tuple[Tuple[str, str, float], ...] = field(default_factory=tuple)

    def __and__(self, other: "Guard") -> Optional["Guard"]:
        merged = list(self.atoms) + list(other.atoms)
        normalized: Dict[str, Dict[str, float]] = {}
        for var, op, val in merged:
            normalized.setdefault(var, {})[op] = val
        for var, ops in normalized.items():
            if "==" in ops and "!=" in ops and ops["=="] == ops["!="]:
                return None
        canonical = []
        seen = set()
        for atom in merged:
            if atom not in seen:
                seen.add(atom)
                canonical.append(atom)
        canonical.sort()
        return Guard(tuple(canonical))

    def __str__(self) -> str:
        if not self.atoms:
            return "TRUE"
        return " ∧ ".join(f"{v} {op} {c:g}" for v, op, c in self.atoms)


TRUE_GUARD = Guard(())


def eq_guard(var: str, value: float = 0.0) -> Guard:
    return Guard(((var, "==", value),))


def neq_guard(var: str, value: float = 0.0) -> Guard:
    return Guard(((var, "!=", value),))


@dataclass(frozen=True)
class CoreValue:
    name: str
    metadata: Dict[str, str] = field(default_factory=dict)

    def __str__(self) -> str:
        if self.metadata:
            meta = ", ".join(f"{k}={v}" for k, v in self.metadata.items())
            return f"{self.name}<{meta}>"
        return self.name


Scalar = Union[float, CoreValue]


def s_add(a: Scalar, b: Scalar) -> Scalar:
    if isinstance(a, CoreValue) or isinstance(b, CoreValue):
        return CoreValue(f"ADD({a},{b})")
    return float(a) + float(b)


def s_sub(a: Scalar, b: Scalar) -> Scalar:
    if isinstance(a, CoreValue) or isinstance(b, CoreValue):
        return CoreValue(f"SUB({a},{b})")
    return float(a) - float(b)


def s_mul(a: Scalar, b: Scalar) -> Scalar:
    if isinstance(a, CoreValue) or isinstance(b, CoreValue):
        return CoreValue(f"MUL({a},{b})")
    return float(a) * float(b)


def s_div(a: Scalar, b: Scalar) -> Scalar:
    if isinstance(a, CoreValue) or isinstance(b, CoreValue):
        return CoreValue(f"DIV({a},{b})")
    if float(b) == 0.0:
        return CoreValue("DIV_ZERO")
    return float(a) / float(b)


# ============================================================
# Tensor and chart objects
# ============================================================

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], Scalar]
    dim: int
    variance: str = ""

    def get(self, idx: Tuple[int, ...]) -> Scalar:
        return self.components.get(idx, 0.0)


def tensor_matrix_string(t: Tensor, name: str) -> str:
    lines = [name]
    for i in range(t.dim):
        row = [str(t.get((i, j))) for j in range(t.dim)]
        lines.append("  [" + ", ".join(row) + "]")
    return "\n".join(lines)


@dataclass
class BranchTensor:
    cases: List[Tuple[Guard, Tensor]]

    def pretty(self, name: str = "BT") -> str:
        lines = [f"{name} = BranchTensor{{"]
        for g, t in self.cases:
            lines.append(f"  [{g}]")
            for k in sorted(t.components):
                lines.append(f"    {k}: {t.components[k]}")
        lines.append("}")
        return "\n".join(lines)


@dataclass
class MetricChart2D:
    """
    2D chart with coordinates x^0, x^1 and covariant metric g_{ab}(r).
    For this prototype the metric depends only on r = x^1.
    """
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]
    valid_guard: Guard


def inverse_metric_2x2(t: Tensor) -> Tensor:
    a = t.get((0, 0))
    b = t.get((0, 1))
    c = t.get((1, 0))
    d = t.get((1, 1))
    if any(isinstance(x, CoreValue) for x in (a, b, c, d)):
        return Tensor(
            rank=2,
            components={
                (0, 0): CoreValue("GINV00"),
                (0, 1): CoreValue("GINV01"),
                (1, 0): CoreValue("GINV10"),
                (1, 1): CoreValue("GINV11"),
            },
            dim=2,
            variance="uu",
        )
    det = float(a) * float(d) - float(b) * float(c)
    if abs(det) < 1e-14:
        raise ValueError("Metric non-invertible on this branch")
    return Tensor(
        rank=2,
        components={
            (0, 0): float(d) / det,
            (0, 1): -float(b) / det,
            (1, 0): -float(c) / det,
            (1, 1): float(a) / det,
        },
        dim=2,
        variance="uu",
    )


# ============================================================
# Metric definitions
# ============================================================

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    # ds^2 = -(1-2M/r) dv^2 + 2 dv dr
    if r == 0.0:
        return Tensor(
            rank=2,
            components={
                (0, 0): CoreValue("EFCORE00"),
                (0, 1): CoreValue("EFCORE01"),
                (1, 0): CoreValue("EFCORE10"),
                (1, 1): CoreValue("EFCORE11"),
            },
            dim=2,
            variance="dd",
        )
    f = 1.0 - 2.0 * M / r
    return Tensor(
        rank=2,
        components={
            (0, 0): -f,
            (0, 1): 1.0,
            (1, 0): 1.0,
            (1, 1): 0.0,
        },
        dim=2,
        variance="dd",
    )


def metric_schwarzschild_tr(M: float, r: float) -> Tensor:
    # ds^2 = -(1-2M/r) dt^2 + (1-2M/r)^(-1) dr^2
    if r == 0.0:
        return Tensor(
            rank=2,
            components={
                (0, 0): CoreValue("SCHWCORE00"),
                (1, 1): CoreValue("SCHWCORE11"),
            },
            dim=2,
            variance="dd",
        )
    f = 1.0 - 2.0 * M / r
    if abs(f) < 1e-14:
        raise ValueError("Schwarzschild chart singular at r=2M")
    return Tensor(
        rank=2,
        components={
            (0, 0): -f,
            (1, 1): 1.0 / f,
        },
        dim=2,
        variance="dd",
    )


# ============================================================
# Fixed-guard derivatives
# ============================================================

def derivative_metric_component(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> Scalar:
    """
    Partial derivative ∂_mu g_{ij}. Since metric depends only on r=x^1, derivative wrt x^0 is zero.
    """
    if r <= h:
        return CoreValue("BOUNDARY_DERIVATIVE", {"component": f"{i}{j}", "coord": str(mu)})
    if mu == 0:
        return 0.0
    gp = chart.g_cov_fn(r + h).get((i, j))
    gm = chart.g_cov_fn(r - h).get((i, j))
    if isinstance(gp, CoreValue) or isinstance(gm, CoreValue):
        return CoreValue("DERIV_CORE", {"component": f"{i}{j}"})
    return (float(gp) - float(gm)) / (2.0 * h)


# ============================================================
# Christoffel symbols
# ============================================================

def christoffel_numeric(chart: MetricChart2D, r: float) -> Tensor:
    """
    Γ^rho_{mu nu} for 2D metric, branch-local numeric computation.
    """
    g_cov = chart.g_cov_fn(r)
    g_inv = inverse_metric_2x2(g_cov)
    dim = 2
    comps: Dict[Tuple[int, int, int], Scalar] = {}

    for rho in range(dim):
        for mu in range(dim):
            for nu in range(dim):
                total: Scalar = 0.0
                for sigma in range(dim):
                    term1 = derivative_metric_component(chart, sigma, nu, mu, r)
                    term2 = derivative_metric_component(chart, sigma, mu, nu, r)
                    term3 = derivative_metric_component(chart, mu, nu, sigma, r)
                    inside = s_sub(s_add(term1, term2), term3)
                    total = s_add(total, s_mul(g_inv.get((rho, sigma)), inside))
                comps[(rho, mu, nu)] = s_mul(0.5, total)
    return Tensor(rank=3, components=comps, dim=2, variance="udd")


def christoffel_branch(chart: MetricChart2D) -> BranchTensor:
    """
    Symbolic branch shell, not full symbolic differentiation.
    """
    regular = Tensor(
        rank=3,
        components={(0, 0, 0): CoreValue("GAMMA_EXPR", {"chart": chart.name, "guard": "r!=0"})},
        dim=2,
        variance="udd",
    )
    core = Tensor(
        rank=3,
        components={(0, 0, 0): CoreValue("GAMMA_CORE", {"chart": chart.name, "guard": "r=0"})},
        dim=2,
        variance="udd",
    )
    return BranchTensor([(neq_guard("r", 0.0), regular), (eq_guard("r", 0.0), core)])


# ============================================================
# Curvature tensors
# ============================================================

def derivative_christoffel(chart: MetricChart2D, rho: int, nu: int, sigma: int, mu: int, r: float, h: float = 1e-5) -> Scalar:
    if r <= h:
        return CoreValue("BOUNDARY_DGAMMA", {"component": f"{rho}{nu}{sigma}", "coord": str(mu)})
    if mu == 0:
        return 0.0
    gp = christoffel_numeric(chart, r + h).get((rho, nu, sigma))
    gm = christoffel_numeric(chart, r - h).get((rho, nu, sigma))
    if isinstance(gp, CoreValue) or isinstance(gm, CoreValue):
        return CoreValue("DGAMMA_CORE")
    return (float(gp) - float(gm)) / (2.0 * h)


def riemann_numeric(chart: MetricChart2D, r: float) -> Tensor:
    dim = 2
    gamma = christoffel_numeric(chart, r)
    comps: Dict[Tuple[int, int, int, int], Scalar] = {}
    for rho in range(dim):
        for sigma in range(dim):
            for mu in range(dim):
                for nu in range(dim):
                    a = derivative_christoffel(chart, rho, nu, sigma, mu, r)
                    b = derivative_christoffel(chart, rho, mu, sigma, nu, r)
                    total = s_sub(a, b)
                    for lam in range(dim):
                        c1 = s_mul(gamma.get((rho, mu, lam)), gamma.get((lam, nu, sigma)))
                        c2 = s_mul(gamma.get((rho, nu, lam)), gamma.get((lam, mu, sigma)))
                        total = s_add(total, s_sub(c1, c2))
                    comps[(rho, sigma, mu, nu)] = total
    return Tensor(rank=4, components=comps, dim=2, variance="uddd")


def ricci_numeric(chart: MetricChart2D, r: float) -> Tensor:
    dim = 2
    R = riemann_numeric(chart, r)
    comps: Dict[Tuple[int, int], Scalar] = {}
    for sigma in range(dim):
        for nu in range(dim):
            total: Scalar = 0.0
            for rho in range(dim):
                total = s_add(total, R.get((rho, sigma, rho, nu)))
            comps[(sigma, nu)] = total
    return Tensor(rank=2, components=comps, dim=2, variance="dd")


def scalar_curvature_numeric(chart: MetricChart2D, r: float) -> Scalar:
    g_cov = chart.g_cov_fn(r)
    g_inv = inverse_metric_2x2(g_cov)
    Ric = ricci_numeric(chart, r)
    total: Scalar = 0.0
    for mu in range(2):
        for nu in range(2):
            total = s_add(total, s_mul(g_inv.get((mu, nu)), Ric.get((mu, nu))))
    return total


# ============================================================
# Branch-aware geodesic acceleration from Christoffel
# ============================================================

def geodesic_acceleration(chart: MetricChart2D, r: float, velocity: Tuple[float, float]) -> Tuple[Scalar, Scalar]:
    gamma = christoffel_numeric(chart, r)
    acc = []
    for rho in range(2):
        total: Scalar = 0.0
        for mu in range(2):
            for nu in range(2):
                total = s_add(total, s_mul(gamma.get((rho, mu, nu)), velocity[mu] * velocity[nu]))
        acc.append(s_mul(-1.0, total))
    return acc[0], acc[1]


# ============================================================
# Demo / report
# ============================================================

def report_chart(chart: MetricChart2D, sample_rs: List[float], sample_velocity: Tuple[float, float]) -> str:
    lines: List[str] = []
    lines.append(f"=== Chart: {chart.name} ===")
    lines.append(f"coords = {chart.coord_names}")
    lines.append(christoffel_branch(chart).pretty("Γ_branch"))
    lines.append("")

    for r in sample_rs:
        lines.append(f"r = {r:g}")
        try:
            g = chart.g_cov_fn(r)
            ginv = inverse_metric_2x2(g)
            Gamma = christoffel_numeric(chart, r)
            Ric = ricci_numeric(chart, r)
            Rsc = scalar_curvature_numeric(chart, r)
            a0, a1 = geodesic_acceleration(chart, r, sample_velocity)

            lines.append(tensor_matrix_string(g, "  metric g_ab"))
            lines.append(tensor_matrix_string(ginv, "  inverse g^ab"))
            lines.append("  selected Christoffel components:")
            for key in sorted(Gamma.components):
                val = Gamma.get(key)
                if abs(float(val)) > 1e-10 if not isinstance(val, CoreValue) else True:
                    lines.append(f"    Γ^{key[0]}_{{{key[1]}{key[2]}}} = {val}")
            lines.append(tensor_matrix_string(Ric, "  Ricci R_ab"))
            lines.append(f"  scalar curvature R = {Rsc}")
            lines.append(f"  geodesic acceleration for u={sample_velocity}: a^0={a0}, a^1={a1}")
        except Exception as exc:
            lines.append(f"  failure: {exc}")
        lines.append("")
    return "\n".join(lines)


def demo_report() -> str:
    ef = MetricChart2D(
        name="EF_ingoing_2D",
        coord_names=("v", "r"),
        g_cov_fn=lambda r: metric_ef_ingoing(1.0, r),
        valid_guard=neq_guard("r", 0.0),
    )
    schw = MetricChart2D(
        name="Schwarzschild_t_r_2D",
        coord_names=("t", "r"),
        g_cov_fn=lambda r: metric_schwarzschild_tr(1.0, r),
        valid_guard=neq_guard("r", 0.0),
    )

    lines: List[str] = []
    lines.append("=== branch_geometry_layer_v2 ===")
    lines.append("")
    lines.append("This upgrade adds:")
    lines.append("- branch-aware Christoffel symbol layer")
    lines.append("- branch-aware curvature layer (Riemann, Ricci, scalar curvature)")
    lines.append("- geodesic acceleration from Christoffel symbols")
    lines.append("")
    lines.append("Important limits:")
    lines.append("- numeric fixed-guard derivatives only")
    lines.append("- 2D charts only")
    lines.append("- branch shells are symbolic, curvature values are computed numerically on regular branches")
    lines.append("")

    lines.append(report_chart(ef, [10.0, 2.0, 1.0], (1.0, -0.2)))
    lines.append(report_chart(schw, [10.0, 1.0], (1.0, -0.2)))

    lines.append("Assessment:")
    lines.append("- EF chart remains regular at the horizon in this 2D model.")
    lines.append("- Schwarzschild chart is excluded at r=2M, consistent with earlier tests.")
    lines.append("- Christoffel/curvature data are now wired into geodesic acceleration.")
    lines.append("- The remaining unresolved place is still the core branch at r=0.")
    lines.append("")
    lines.append("Next direct upgrade:")
    lines.append("- integrate geodesics using these Christoffel symbols instead of first-integral shortcuts")
    return "\n".join(lines)


if __name__ == "__main__":
    print(demo_report())
