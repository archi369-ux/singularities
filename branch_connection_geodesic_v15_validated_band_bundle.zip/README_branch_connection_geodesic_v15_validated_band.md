# Branch Connection Geodesic v15 Validated Band

Reduced validation sample for the current strongest prototype law.
