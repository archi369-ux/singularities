
# Branch Connection Geodesic v12 Constraint Preserving Reset

Compares reset families:

- inconsistent damped-flip
- constraint-preserving A: choose outgoing u^r, solve u^v from g(u,u)=-1
- constraint-preserving B: choose outgoing u^v, solve u^r from g(u,u)=-1

Goal:
find out whether constraint consistency can be restored without losing stable outward recovery.
