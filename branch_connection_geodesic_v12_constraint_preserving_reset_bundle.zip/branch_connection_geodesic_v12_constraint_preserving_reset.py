
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""

    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))


@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]


def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0, 0): -f, (0, 1): 1.0, (1, 0): 1.0, (1, 1): 0.0}, 2, "dd")


def inverse_metric_2x2(t: Tensor) -> Tensor:
    a, b, c, d = t.get((0, 0)), t.get((0, 1)), t.get((1, 0)), t.get((1, 1))
    det = a * d - b * c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0, 0): d / det, (0, 1): -b / det, (1, 0): -c / det, (1, 1): a / det}, 2, "uu")


def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r + h).get((i, j)) - chart.g_cov_fn(r - h).get((i, j))) / (2.0 * h)


def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart, sigma, nu, mu, r) + dmetric(chart, sigma, mu, nu, r) - dmetric(chart, mu, nu, sigma, r)
                    total += gi.get((rho, sigma)) * inside
                c[(rho, mu, nu)] = 0.5 * total
    return Tensor(3, c, 2, "udd")


def rhs(chart: MetricChart2D, s: Tuple[float, float, float, float]):
    x0, r, u0, ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0, mu, nu)) * vel[mu] * vel[nu]
            ar -= G.get((1, mu, nu)) * vel[mu] * vel[nu]
    return (u0, ur, a0, ar)


def rk4(f, s, h):
    def add(a, b, c):
        return tuple(ai + c * bi for ai, bi in zip(a, b))
    k1 = f(s)
    k2 = f(add(s, k1, 0.5 * h))
    k3 = f(add(s, k2, 0.5 * h))
    k4 = f(add(s, k3, h))
    return tuple(si + (h / 6.0) * (a + 2 * b + 2 * c + d) for si, a, b, c, d in zip(s, k1, k2, k3, k4))


def ef_initial_conditions_from_energy(E: float, M: float = 1.0, r0: float = 10.0):
    f = 1.0 - 2.0 * M / r0
    ur = -math.sqrt(max(0.0, E * E - f))
    uv = (E + ur) / f if abs(f) > 1e-14 else 1.0 / (E + math.sqrt(max(0.0, E * E - f)))
    return uv, ur


def choose_dtau(base, r, ur):
    return max(1e-9, base * min(1.0, max(1e-6, r / 0.3)) * min(1.0, 1.0 / max(1.0, abs(ur) / 5.0)))


def timelike_constraint(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    return g.get((0, 0)) * u0 * u0 + g.get((0, 1)) * u0 * ur + g.get((1, 0)) * ur * u0 + g.get((1, 1)) * ur * ur


def solve_u0_from_constraint(chart: MetricChart2D, r: float, ur: float, sign_hint: float | None = None) -> float:
    g = chart.g_cov_fn(r)
    f = -g.get((0, 0))
    a = f
    b = -2.0 * ur
    c = -1.0
    if abs(a) < 1e-14:
        if abs(b) < 1e-14:
            raise ValueError("degenerate constraint coefficients")
        return -c / b
    disc = b * b - 4.0 * a * c
    if disc < 0:
        raise ValueError(f"negative discriminant: {disc}")
    root = math.sqrt(disc)
    u0_1 = (-b + root) / (2.0 * a)
    u0_2 = (-b - root) / (2.0 * a)
    if sign_hint is None:
        positives = [x for x in (u0_1, u0_2) if x > 0]
        if positives:
            return min(positives, key=abs)
        return u0_1
    return u0_1 if abs(u0_1 - sign_hint) <= abs(u0_2 - sign_hint) else u0_2


def make_constraint_A_reset(chart: MetricChart2D, x0: float, incoming_u0: float, incoming_ur: float, r_reset: float, damping: float):
    """
    Choose outgoing ur by damping, but back off further if needed until the timelike constraint is solvable.
    """
    target_ur = damping * abs(incoming_ur)
    scale = 1.0
    last_exc = None
    for _ in range(40):
        ur_out = target_ur * scale
        try:
            u0_out = solve_u0_from_constraint(chart, r_reset, ur_out, sign_hint=max(incoming_u0, 0.0))
            return (x0, r_reset, u0_out, ur_out, f"constraint_A_scaled(scale={scale:.6f})")
        except Exception as exc:
            last_exc = exc
            scale *= 0.8
    raise ValueError(f"constraint_A could not find solvable outgoing ur: {last_exc}")


def make_constraint_B_reset(chart: MetricChart2D, x0: float, incoming_u0: float, incoming_ur: float, r_reset: float, damping: float):
    """
    Choose target u0 by damping incoming u0, solve ur from constraint.
    """
    target_u0 = max(1e-8, damping * abs(incoming_u0))
    g = chart.g_cov_fn(r_reset)
    f = -g.get((0, 0))
    ur_out = (-1.0 + f * target_u0 * target_u0) / (2.0 * target_u0)
    if ur_out < 0:
        ur_out = abs(ur_out)
        target_u0 = solve_u0_from_constraint(chart, r_reset, ur_out, sign_hint=target_u0)
    return (x0, r_reset, target_u0, ur_out, "constraint_B")


def make_inconsistent_reset(x0: float, incoming_u0: float, incoming_ur: float, r_reset: float, damping: float):
    return (x0, r_reset, incoming_u0, damping * abs(incoming_ur), "inconsistent_damped_flip")


@dataclass
class ResetCompareResult:
    label: str
    outcome: str
    reset_family: str
    trigger_tau: float
    first_err: float
    mean_err: float
    max_err: float
    final_err: float
    final_ur: float
    tau_end: float
    retriggers: int
    notes: str


def simulate_reset_family(
    E: float,
    M: float,
    reset_family: str,
    r_trigger: float = 3e-2,
    r_reset: float = 1.0,
    damping: float = 0.10,
    ur_limit: float = 50.0,
    gamma_limit: float = 1e5,
    base_dtau: float = 1e-3,
    max_steps: int = 70000,
):
    chart = MetricChart2D(f"EF_ingoing_2D_M{M:.2f}", ("v", "r"), lambda r: metric_ef_ingoing(M, r))
    uv0, ur0 = ef_initial_conditions_from_energy(E, M=M)
    s = (0.0, 10.0, uv0, ur0)
    tau = 0.0
    triggered = False
    retriggers = 0
    trigger_tau = float("nan")
    after_errors: List[float] = []
    notes: List[str] = []

    for _ in range(max_steps):
        x0, r, u0, ur = s
        dt = choose_dtau(base_dtau, r, ur)
        gm = max(abs(v) for v in christoffel(chart, r).components.values())
        c_now = timelike_constraint(chart, r, u0, ur)

        if triggered:
            after_errors.append(abs(c_now + 1.0))

        if (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit):
            if not triggered:
                trigger_tau = tau
                try:
                    if reset_family == "inconsistent":
                        s = make_inconsistent_reset(x0, u0, ur, r_reset, damping)[:4]
                        family_name = "inconsistent_damped_flip"
                    elif reset_family == "constraint_A":
                        s = make_constraint_A_reset(chart, x0, u0, ur, r_reset, damping)[:4]
                        family_name = "constraint_A"
                    elif reset_family == "constraint_B":
                        s = make_constraint_B_reset(chart, x0, u0, ur, r_reset, damping)[:4]
                        family_name = "constraint_B"
                    else:
                        raise ValueError(f"unknown reset family: {reset_family}")
                except Exception as exc:
                    notes.append(f"reset failure: {exc}")
                    return ResetCompareResult(
                        label=f"M={M:.2f},E={E:.2f}",
                        outcome="reset-failure",
                        reset_family=reset_family,
                        trigger_tau=trigger_tau,
                        first_err=float("nan"),
                        mean_err=float("nan"),
                        max_err=float("nan"),
                        final_err=float("nan"),
                        final_ur=ur,
                        tau_end=tau,
                        retriggers=retriggers,
                        notes="; ".join(notes),
                    )
                triggered = True
                c_reset = timelike_constraint(chart, s[1], s[2], s[3])
                after_errors.append(abs(c_reset + 1.0))
                notes.append(f"trigger at tau={tau:.6f}, r={r:.6e}, family={family_name}, g(u,u)_reset={c_reset:.6e}")
                continue
            else:
                retriggers += 1
                notes.append(f"retrigger at tau={tau:.6f}, r={r:.6e}")
                if retriggers > 5:
                    return ResetCompareResult(
                        label=f"M={M:.2f},E={E:.2f}",
                        outcome="retrigger-loop",
                        reset_family=reset_family,
                        trigger_tau=trigger_tau,
                        first_err=after_errors[0] if after_errors else float("nan"),
                        mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
                        max_err=max(after_errors) if after_errors else float("nan"),
                        final_err=after_errors[-1] if after_errors else float("nan"),
                        final_ur=s[3],
                        tau_end=tau,
                        retriggers=retriggers,
                        notes="; ".join(notes),
                    )

        try:
            s = rk4(lambda y: rhs(chart, y), s, dt)
        except Exception as exc:
            notes.append(f"integration failure: {exc}")
            return ResetCompareResult(
                label=f"M={M:.2f},E={E:.2f}",
                outcome="failure",
                reset_family=reset_family,
                trigger_tau=trigger_tau,
                first_err=after_errors[0] if after_errors else float("nan"),
                mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
                max_err=max(after_errors) if after_errors else float("nan"),
                final_err=after_errors[-1] if after_errors else float("nan"),
                final_ur=s[3],
                tau_end=tau,
                retriggers=retriggers,
                notes="; ".join(notes),
            )

        tau += dt
        if triggered and s[1] >= 10.0:
            c_final = timelike_constraint(chart, s[1], s[2], s[3])
            after_errors.append(abs(c_final + 1.0))
            return ResetCompareResult(
                label=f"M={M:.2f},E={E:.2f}",
                outcome="post-core-outgoing",
                reset_family=reset_family,
                trigger_tau=trigger_tau,
                first_err=after_errors[0] if after_errors else float("nan"),
                mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
                max_err=max(after_errors) if after_errors else float("nan"),
                final_err=after_errors[-1] if after_errors else float("nan"),
                final_ur=s[3],
                tau_end=tau,
                retriggers=retriggers,
                notes="; ".join(notes),
            )

    return ResetCompareResult(
        label=f"M={M:.2f},E={E:.2f}",
        outcome="max-steps",
        reset_family=reset_family,
        trigger_tau=trigger_tau,
        first_err=after_errors[0] if after_errors else float("nan"),
        mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
        max_err=max(after_errors) if after_errors else float("nan"),
        final_err=after_errors[-1] if after_errors else float("nan"),
        final_ur=s[3],
        tau_end=tau,
        retriggers=retriggers,
        notes="; ".join(notes),
    )


def summarize(results: List[ResetCompareResult]) -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v12_constraint_preserving_reset ===")
    lines.append("")
    lines.append("Comparing reset families:")
    lines.append("- inconsistent damped-flip")
    lines.append("- constraint-preserving A: choose ur, solve u0")
    lines.append("- constraint-preserving B: choose u0, solve ur")
    lines.append("")
    for r in results:
        lines.append(
            f"- {r.label} / {r.reset_family}: outcome={r.outcome}, "
            f"first_err={r.first_err:.3e}, mean_err={r.mean_err:.3e}, max_err={r.max_err:.3e}, "
            f"final_err={r.final_err:.3e}, final_ur={r.final_ur:.3e}, retriggers={r.retriggers}"
        )
    lines.append("")
    lines.append("Interpretation:")
    lines.append("- A good upgrade must reduce the constraint error drastically without destroying outward recovery.")
    lines.append("- If a constraint-preserving family keeps recovery and cuts error toward numerical tolerance, it beats the current default.")
    lines.append("- If it preserves the constraint but loses recovery, then geometric consistency and numerical continuation are still in tension.")
    return "\n".join(lines)


def csv_table(results: List[ResetCompareResult]) -> str:
    lines = ["label,reset_family,outcome,trigger_tau,first_err,mean_err,max_err,final_err,final_ur,tau_end,retriggers,notes"]
    for r in results:
        lines.append(
            f"{r.label},{r.reset_family},{r.outcome},{r.trigger_tau:.6f},{r.first_err:.6e},{r.mean_err:.6e},{r.max_err:.6e},"
            f"{r.final_err:.6e},{r.final_ur:.6e},{r.tau_end:.6f},{r.retriggers},\"{r.notes}\""
        )
    return "\n".join(lines)


def main():
    cases = [(1.0, 1.0), (0.95, 1.0), (1.0, 1.25)]
    families = ["inconsistent", "constraint_A", "constraint_B"]
    results: List[ResetCompareResult] = []
    for E, M in cases:
        for fam in families:
            results.append(simulate_reset_family(E=E, M=M, reset_family=fam))

    print(summarize(results))
    print("")
    print("--- CSV TABLE ---")
    print(csv_table(results))

if __name__ == "__main__":
    main()
