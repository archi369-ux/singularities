
# Branch Connection Geodesic v11 Constraint Consistency

Checks constraint consistency after reset for the current default branch law.

Tracked quantity:
- timelike normalization g_ab u^a u^b ≈ -1

Tested cases:
- M=1.00, E=1.00
- M=1.00, E=0.95
- M=1.25, E=1.00
