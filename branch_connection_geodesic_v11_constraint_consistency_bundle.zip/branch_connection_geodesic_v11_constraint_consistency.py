
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

# ============================================================
# Geometry
# ============================================================

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

# ============================================================
# Dynamics
# ============================================================

def rhs(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(f, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = f(s); k2 = f(add(s,k1,0.5*h)); k3 = f(add(s,k2,0.5*h)); k4 = f(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(E: float, M: float = 1.0, r0: float = 10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(max(0.0, E*E - f))
    uv = (E + ur)/f if abs(f) > 1e-14 else 1.0/(E + math.sqrt(max(0.0, E*E - f)))
    return uv, ur

def choose_dtau(base, r, ur):
    return max(1e-9, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

# ============================================================
# Constraint / normalization checks
# ============================================================

def timelike_constraint(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    # g_ab u^a u^b
    return (
        g.get((0,0))*u0*u0
        + g.get((0,1))*u0*ur
        + g.get((1,0))*ur*u0
        + g.get((1,1))*ur*ur
    )

def expected_timelike_value() -> float:
    # geometric units timelike proper-time normalization
    return -1.0

@dataclass
class ConstraintSnapshot:
    tau: float
    r: float
    u0: float
    ur: float
    cval: float
    abs_error: float
    note: str

@dataclass
class ConsistencyResult:
    label: str
    outcome: str
    trigger_tau: float
    reset_tau: float
    max_abs_error_after_reset: float
    mean_abs_error_after_reset: float
    first_error_after_reset: float
    final_abs_error: float
    snapshots: List[ConstraintSnapshot]
    notes: List[str]

    def summary(self, tail: int = 8) -> str:
        lines = [
            f"Case: {self.label}",
            f"Outcome: {self.outcome}",
            f"trigger_tau={self.trigger_tau:.6f}",
            f"reset_tau={self.reset_tau:.6f}",
            f"first_abs_error_after_reset={self.first_error_after_reset:.6e}",
            f"mean_abs_error_after_reset={self.mean_abs_error_after_reset:.6e}",
            f"max_abs_error_after_reset={self.max_abs_error_after_reset:.6e}",
            f"final_abs_error={self.final_abs_error:.6e}",
            "Notes:",
        ]
        if self.notes:
            lines.extend(f"- {n}" for n in self.notes)
        else:
            lines.append("- none")
        lines.append("")
        lines.append("Constraint snapshots:")
        for s in self.snapshots[-tail:]:
            lines.append(
                f"tau={s.tau:.6f}, r={s.r:.6e}, u0={s.u0:.6e}, ur={s.ur:.6e}, "
                f"g(u,u)={s.cval:.6e}, |err|={s.abs_error:.6e} [{s.note}]"
            )
        return "\n".join(lines)

def simulate_and_check_constraints(
    E: float = 1.0,
    M: float = 1.0,
    r_trigger: float = 3e-2,
    r_reset: float = 1.0,
    damping: float = 0.10,
    ur_limit: float = 50.0,
    gamma_limit: float = 1e5,
    base_dtau: float = 1e-3,
    max_steps: int = 70000,
) -> ConsistencyResult:
    chart = MetricChart2D(f"EF_ingoing_2D_M{M:.2f}", ("v","r"), lambda r: metric_ef_ingoing(M, r))
    uv0, ur0 = ef_initial_conditions_from_energy(E, M=M)
    s = (0.0, 10.0, uv0, ur0)
    tau = 0.0

    trigger_tau = float("nan")
    reset_tau = float("nan")
    triggered = False
    after_reset_errors: List[float] = []
    snapshots: List[ConstraintSnapshot] = []
    notes: List[str] = []

    for step_idx in range(max_steps):
        x0, r, u0, ur = s
        dt = choose_dtau(base_dtau, r, ur)

        # current constraint before any trigger/reset
        cval = timelike_constraint(chart, r, u0, ur)
        err = abs(cval - expected_timelike_value())
        if step_idx < 5:
            snapshots.append(ConstraintSnapshot(tau, r, u0, ur, cval, err, "initial"))
        if triggered:
            after_reset_errors.append(err)
            if len(after_reset_errors) <= 5 or step_idx % 5000 == 0:
                snapshots.append(ConstraintSnapshot(tau, r, u0, ur, cval, err, "post-reset"))

        gm = max(abs(v) for v in christoffel(chart, r).components.values())
        if (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit) and not triggered:
            trigger_tau = tau
            # snapshot just before reset
            snapshots.append(ConstraintSnapshot(tau, r, u0, ur, cval, err, "pre-reset"))
            # apply current default reset law
            s = (x0, r_reset, u0, damping*abs(ur))
            reset_tau = tau
            triggered = True
            x0r, rr, u0r, urr = s
            cval_r = timelike_constraint(chart, rr, u0r, urr)
            err_r = abs(cval_r - expected_timelike_value())
            after_reset_errors.append(err_r)
            snapshots.append(ConstraintSnapshot(tau, rr, u0r, urr, cval_r, err_r, "immediate-reset"))
            notes.append(f"trigger at r={r:.6e}, |ur|={abs(ur):.6e}, |Gamma|max={gm:.6e}")
            continue

        try:
            s = rk4(lambda y: rhs(chart, y), s, dt)
        except Exception as exc:
            notes.append(f"integration failure: {exc}")
            if after_reset_errors:
                return ConsistencyResult(
                    label=f"M={M:.2f},E={E:.2f}",
                    outcome="failure",
                    trigger_tau=trigger_tau,
                    reset_tau=reset_tau,
                    max_abs_error_after_reset=max(after_reset_errors),
                    mean_abs_error_after_reset=sum(after_reset_errors)/len(after_reset_errors),
                    first_error_after_reset=after_reset_errors[0],
                    final_abs_error=after_reset_errors[-1],
                    snapshots=snapshots,
                    notes=notes,
                )
            return ConsistencyResult(
                label=f"M={M:.2f},E={E:.2f}",
                outcome="failure",
                trigger_tau=trigger_tau,
                reset_tau=reset_tau,
                max_abs_error_after_reset=float("nan"),
                mean_abs_error_after_reset=float("nan"),
                first_error_after_reset=float("nan"),
                final_abs_error=float("nan"),
                snapshots=snapshots,
                notes=notes,
            )

        tau += dt
        if triggered and s[1] >= 10.0:
            x0f, rf, u0f, urf = s
            cval_f = timelike_constraint(chart, rf, u0f, urf)
            err_f = abs(cval_f - expected_timelike_value())
            after_reset_errors.append(err_f)
            snapshots.append(ConstraintSnapshot(tau, rf, u0f, urf, cval_f, err_f, "final"))
            notes.append("recovered to r>=10")
            return ConsistencyResult(
                label=f"M={M:.2f},E={E:.2f}",
                outcome="post-core-outgoing",
                trigger_tau=trigger_tau,
                reset_tau=reset_tau,
                max_abs_error_after_reset=max(after_reset_errors),
                mean_abs_error_after_reset=sum(after_reset_errors)/len(after_reset_errors),
                first_error_after_reset=after_reset_errors[0],
                final_abs_error=after_reset_errors[-1],
                snapshots=snapshots,
                notes=notes,
            )

    notes.append("max_steps")
    if after_reset_errors:
        return ConsistencyResult(
            label=f"M={M:.2f},E={E:.2f}",
            outcome="max-steps",
            trigger_tau=trigger_tau,
            reset_tau=reset_tau,
            max_abs_error_after_reset=max(after_reset_errors),
            mean_abs_error_after_reset=sum(after_reset_errors)/len(after_reset_errors),
            first_error_after_reset=after_reset_errors[0],
            final_abs_error=after_reset_errors[-1],
            snapshots=snapshots,
            notes=notes,
        )
    return ConsistencyResult(
        label=f"M={M:.2f},E={E:.2f}",
        outcome="max-steps",
        trigger_tau=trigger_tau,
        reset_tau=reset_tau,
        max_abs_error_after_reset=float("nan"),
        mean_abs_error_after_reset=float("nan"),
        first_error_after_reset=float("nan"),
        final_abs_error=float("nan"),
        snapshots=snapshots,
        notes=notes,
    )

def csv_table(results: List[ConsistencyResult]) -> str:
    lines = ["label,outcome,trigger_tau,reset_tau,first_abs_error_after_reset,mean_abs_error_after_reset,max_abs_error_after_reset,final_abs_error,notes"]
    for r in results:
        lines.append(
            f"{r.label},{r.outcome},{r.trigger_tau:.6f},{r.reset_tau:.6f},"
            f"{r.first_error_after_reset:.6e},{r.mean_abs_error_after_reset:.6e},"
            f"{r.max_abs_error_after_reset:.6e},{r.final_abs_error:.6e},\"{' ; '.join(r.notes)}\""
        )
    return "\n".join(lines)

def summarize(results: List[ConsistencyResult]) -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v11_constraint_consistency ===")
    lines.append("")
    lines.append("Checking timelike normalization consistency after reset.")
    lines.append("Constraint tracked: g_ab u^a u^b should stay near -1.")
    lines.append("")
    for r in results:
        lines.append(
            f"- {r.label}: outcome={r.outcome}, "
            f"first_err={r.first_error_after_reset:.3e}, "
            f"mean_err={r.mean_abs_error_after_reset:.3e}, "
            f"max_err={r.max_abs_error_after_reset:.3e}, "
            f"final_err={r.final_abs_error:.3e}"
        )
    lines.append("")
    lines.append("Interpretation:")
    lines.append("- Small post-reset errors would mean the branch law is not only numerically stable but also roughly compatible with the timelike constraint.")
    lines.append("- Large immediate error means the reset law injects a state that is not geometrically consistent with the chosen metric normalization.")
    lines.append("- If error then relaxes afterward, the flow partially heals the inconsistency; if it stays large, the reset is only a numerical patch.")
    return "\n".join(lines)

def main():
    cases = [(1.0,1.0), (0.95,1.0), (1.0,1.25)]
    results = [simulate_and_check_constraints(E=E, M=M) for E,M in cases]
    print(summarize(results))
    print("")
    for r in results:
        print(r.summary())
        print("")
    print("--- CSV TABLE ---")
    print(csv_table(results))

if __name__ == "__main__":
    main()
