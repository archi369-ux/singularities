
# Branch Connection Geodesic v4 Reset Laws

This bundle tests continuation-reset laws after pre-core trigger activation.

Modes:
- terminate
- sign-flip
- damped-flip
- energy-matched

Also compares baseline reset radius vs farther reset radius.
