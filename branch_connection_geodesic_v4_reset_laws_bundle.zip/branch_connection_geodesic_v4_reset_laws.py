
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

# ============================================================
# Core geometry
# ============================================================

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    G = christoffel(chart, r)
    return max(abs(v) for v in G.components.values())

# ============================================================
# Geodesic ODE
# ============================================================

def rhs(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(f, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = f(s)
    k2 = f(add(s,k1,0.5*h))
    k3 = f(add(s,k2,0.5*h))
    k4 = f(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(M=1.0, E=1.0, r0=10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(E*E - f)
    uv = (E + ur)/f
    return uv, ur

def choose_dtau(base, r, ur):
    return max(1e-9, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

# ============================================================
# Reporting
# ============================================================

@dataclass
class GeodesicState:
    tau: float
    x0: float
    r: float
    u0: float
    ur: float
    dtau_used: float
    note: str = ""
    def line(self) -> str:
        suffix = f" [{self.note}]" if self.note else ""
        return f"tau={self.tau:.6f}, v={self.x0:.6f}, r={self.r:.6e}, u^v={self.u0:.6e}, u^r={self.ur:.6e}, dtau={self.dtau_used:.1e}{suffix}"

@dataclass
class RunResult:
    label: str
    history: List[GeodesicState]
    events: List[str]
    outcome: str
    def summary(self, tail: int = 8) -> str:
        lines = [f"Case: {self.label}", f"Outcome: {self.outcome}", "Events:"]
        lines.extend(f"- {e}" for e in self.events) if self.events else lines.append("- none")
        lines.append("")
        lines.append("Last states:")
        for s in self.history[-tail:]:
            lines.append(s.line())
        return "\n".join(lines)

# ============================================================
# Continuation reset laws
# ============================================================

def reset_sign_flip(x0: float, u0: float, ur: float, r_trigger: float, r_reset: float) -> Tuple[float,float,float,float,str]:
    return (x0, r_reset, u0, abs(ur), f"sign-flip reset to r_reset={r_reset:g}")

def reset_damped_flip(x0: float, u0: float, ur: float, r_trigger: float, r_reset: float, damping: float = 0.25) -> Tuple[float,float,float,float,str]:
    return (x0, r_reset, u0, damping*abs(ur), f"damped-flip reset to r_reset={r_reset:g}, damping={damping:g}")

def reset_energy_matched(x0: float, u0: float, ur: float, r_trigger: float, r_reset: float, M: float = 1.0, E: float = 1.0) -> Tuple[float,float,float,float,str]:
    f = 1.0 - 2.0*M/r_reset
    ur_out = math.sqrt(max(0.0, E*E - f))
    uv_out = (E + ur_out)/f
    return (x0, r_reset, uv_out, ur_out, f"energy-matched reset to r_reset={r_reset:g}")

# ============================================================
# Experiment engine
# ============================================================

def simulate_reset_law(label: str, reset_mode: str, r_trigger: float = 3e-2, r_reset: float = 0.3,
                       ur_limit: float = 50.0, gamma_limit: float = 1e5,
                       base_dtau: float = 1e-3, max_steps: int = 50000) -> RunResult:
    chart = MetricChart2D("EF_ingoing_2D", ("v","r"), lambda r: metric_ef_ingoing(1.0, r))
    uv0, ur0 = ef_initial_conditions_from_energy()
    s = (0.0, 10.0, uv0, ur0)
    tau = 0.0
    hist = [GeodesicState(tau, *s, base_dtau, "start")]
    events: List[str] = []
    crossed_horizon = False
    used_reset = False

    for _ in range(max_steps):
        x0, r, u0, ur = s
        dt = choose_dtau(base_dtau, r, ur)

        if not crossed_horizon and r <= 2.0:
            crossed_horizon = True
            events.append("horizon crossed cleanly in EF")

        gm = gamma_max_abs(chart, r)
        if (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit) and not used_reset:
            hist.append(GeodesicState(tau, x0, r, u0, ur, dt, "trigger"))
            events.append(f"trigger at r={r:.3e}, |u^r|={abs(ur):.3e}, |Gamma|max={gm:.3e}")
            if reset_mode == "terminate":
                events.append("terminate applied")
                return RunResult(label, hist, events, "trigger-stop")
            elif reset_mode == "sign-flip":
                s = reset_sign_flip(x0, u0, ur, r, r_reset)[:4]
                note = reset_sign_flip(x0, u0, ur, r, r_reset)[4]
            elif reset_mode == "damped-flip":
                s = reset_damped_flip(x0, u0, ur, r, r_reset)[:4]
                note = reset_damped_flip(x0, u0, ur, r, r_reset)[4]
            elif reset_mode == "energy-matched":
                s = reset_energy_matched(x0, u0, ur, r, r_reset)[:4]
                note = reset_energy_matched(x0, u0, ur, r, r_reset)[4]
            else:
                return RunResult(label, hist, events + [f"unknown reset_mode={reset_mode}"], "failure")
            used_reset = True
            hist.append(GeodesicState(tau, s[0], s[1], s[2], s[3], dt, note))
            events.append(note)
            continue

        try:
            s = rk4(lambda y: rhs(chart, y), s, dt)
        except Exception as exc:
            events.append(f"integration failure: {exc}")
            return RunResult(label, hist, events, "failure")

        tau += dt
        hist.append(GeodesicState(tau, s[0], s[1], s[2], s[3], dt))

        if used_reset and s[1] >= 10.0:
            events.append("recovered to r>=10")
            return RunResult(label, hist, events, "post-core-outgoing")

    events.append("max_steps")
    return RunResult(label, hist, events, "max-steps")

def full_report() -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v4_reset_laws ===")
    lines.append("")
    lines.append("This run tests continuation-reset laws after pre-core triggering.")
    lines.append("We do not recurse automatically in the future; this run bundles the next improvements now.")
    lines.append("")
    cases = [
        ("baseline/terminate", "terminate"),
        ("baseline/sign-flip", "sign-flip"),
        ("baseline/damped-flip", "damped-flip"),
        ("baseline/energy-matched", "energy-matched"),
        ("far-reset/sign-flip", "sign-flip"),
        ("far-reset/damped-flip", "damped-flip"),
        ("far-reset/energy-matched", "energy-matched"),
    ]
    for label, mode in cases:
        r_reset = 0.3 if label.startswith("baseline") else 1.0
        res = simulate_reset_law(label, mode, r_trigger=3e-2, r_reset=r_reset, ur_limit=50.0, gamma_limit=1e5)
        lines.append(res.summary())
        lines.append("")
    lines.append("Assessment:")
    lines.append("- Reset laws are the right abstraction for post-trigger continuation.")
    lines.append("- Sign-flip tests whether minimal structural change is enough.")
    lines.append("- Damped-flip tests whether velocity suppression reduces re-trigger risk.")
    lines.append("- Energy-matched reset tests whether restarting from classical outgoing data is cleaner.")
    lines.append("- Far-reset cases test whether getting well outside the trigger zone prevents immediate relapse.")
    return "\n".join(lines)

if __name__ == "__main__":
    print(full_report())
