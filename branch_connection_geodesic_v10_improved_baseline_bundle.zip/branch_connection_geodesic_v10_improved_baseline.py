
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

# ============================================================
# Geometry
# ============================================================

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    G = christoffel(chart, r)
    return max(abs(v) for v in G.components.values())

# ============================================================
# Dynamics
# ============================================================

def rhs(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(f, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = f(s); k2 = f(add(s,k1,0.5*h)); k3 = f(add(s,k2,0.5*h)); k4 = f(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(E: float, M: float = 1.0, r0: float = 10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(max(0.0, E*E - f))
    uv = (E + ur)/f if abs(f) > 1e-14 else 1.0/(E + math.sqrt(max(0.0, E*E - f)))
    return uv, ur

def choose_dtau(base, r, ur):
    return max(1e-9, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

def first_integral_rhs(M: float, E: float, r: float, outgoing: bool=False):
    f = 1.0 - 2.0*M/r
    mag = math.sqrt(max(0.0, E*E - f))
    ur = mag if outgoing else -mag
    uv = (E + ur)/f if abs(f) > 1e-14 else 0.0
    return uv, ur

# ============================================================
# Comparison structures
# ============================================================

@dataclass
class CompareResult:
    label: str
    baseline_trigger_tau: float
    improved_trigger_tau: float
    conn_trigger_tau: float
    baseline_final_tau: float
    improved_final_tau: float
    conn_final_tau: float
    baseline_final_ur: float
    improved_final_ur: float
    conn_final_ur: float
    baseline_outcome: str
    improved_outcome: str
    conn_outcome: str
    notes: str

# ============================================================
# Simulators
# ============================================================

def simulate_connection_branchlaw(chart: MetricChart2D, E: float, M: float,
                                  r_trigger: float = 3e-2, r_reset: float = 1.0, damping: float = 0.10,
                                  ur_limit: float = 50.0, gamma_limit: float = 1e5,
                                  base_dtau: float = 1e-3, max_steps: int = 70000):
    uv0, ur0 = ef_initial_conditions_from_energy(E, M=M)
    s = (0.0, 10.0, uv0, ur0)
    tau = 0.0
    triggered = False
    trigger_tau = float("nan")
    for _ in range(max_steps):
        x0, r, u0, ur = s
        dt = choose_dtau(base_dtau, r, ur)
        gm = gamma_max_abs(chart, r)
        if (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit) and not triggered:
            triggered = True
            trigger_tau = tau
            s = (x0, r_reset, u0, damping*abs(ur))
            continue
        s = rk4(lambda y: rhs(chart, y), s, dt)
        tau += dt
        if triggered and s[1] >= 10.0:
            return {"outcome":"post-core-outgoing","trigger_tau":trigger_tau,"tau_end":tau,"final_ur":s[3]}
    return {"outcome":"max-steps","trigger_tau":trigger_tau,"tau_end":tau,"final_ur":s[3]}

def simulate_first_integral_baseline(E: float, M: float,
                                     r_trigger: float = 3e-2, r_reset: float = 1.0, damping: float = 0.10,
                                     base_dtau: float = 1e-3, max_steps: int = 70000):
    x0 = 0.0
    r = 10.0
    tau = 0.0
    triggered = False
    trigger_tau = float("nan")
    ur = float("nan")
    uv = float("nan")
    for _ in range(max_steps):
        if not triggered:
            uv, ur = first_integral_rhs(M, E, r, outgoing=False)
        else:
            uv, ur = first_integral_rhs(M, E, r, outgoing=True)
            ur *= damping
        dt = choose_dtau(base_dtau, r, ur)
        if (r <= r_trigger) and not triggered:
            triggered = True
            trigger_tau = tau
            r = r_reset
            continue
        x0 += uv*dt
        r += ur*dt
        tau += dt
        if triggered and r >= 10.0:
            return {"outcome":"post-core-outgoing","trigger_tau":trigger_tau,"tau_end":tau,"final_ur":ur}
    return {"outcome":"max-steps","trigger_tau":trigger_tau,"tau_end":tau,"final_ur":ur}

def simulate_first_integral_improved(E: float, M: float,
                                     r_trigger: float = 3e-2, r_reset: float = 1.0, damping: float = 0.10,
                                     base_dtau: float = 1e-3, max_steps: int = 70000):
    """
    Improved baseline:
    - uses first-integral incoming branch before trigger
    - after reset, uses first-integral outgoing branch continuously
    - recomputes outgoing uv, ur every step from the same E and current r
    - applies damping multiplicatively only to ur magnitude
    """
    x0 = 0.0
    r = 10.0
    tau = 0.0
    triggered = False
    trigger_tau = float("nan")
    ur = float("nan")
    for _ in range(max_steps):
        if not triggered:
            uv, ur = first_integral_rhs(M, E, r, outgoing=False)
        else:
            uv, ur = first_integral_rhs(M, E, r, outgoing=True)
            ur *= damping
        dt = choose_dtau(base_dtau, r, ur)
        if (r <= r_trigger) and not triggered:
            triggered = True
            trigger_tau = tau
            r = r_reset
            continue
        x0 += uv*dt
        r += ur*dt
        tau += dt
        if triggered and r >= 10.0:
            return {"outcome":"post-core-outgoing","trigger_tau":trigger_tau,"tau_end":tau,"final_ur":ur}
    return {"outcome":"max-steps","trigger_tau":trigger_tau,"tau_end":tau,"final_ur":ur}

# ============================================================
# Report
# ============================================================

def compare_one(E: float, M: float) -> CompareResult:
    chart = MetricChart2D(f"EF_ingoing_2D_M{M:.2f}", ("v","r"), lambda r: metric_ef_ingoing(M, r))
    conn = simulate_connection_branchlaw(chart, E, M)
    base = simulate_first_integral_baseline(E, M)
    imp = simulate_first_integral_improved(E, M)
    notes = []
    if conn["outcome"] == imp["outcome"]:
        notes.append("improved baseline matches connection outcome")
    if base["outcome"] != imp["outcome"]:
        notes.append("improved baseline differs from crude baseline")
    notes.append(f"Δtau(conn-imp)={conn['tau_end']-imp['tau_end']:.6f}")
    return CompareResult(
        label=f"M={M:.2f},E={E:.2f}",
        baseline_trigger_tau=base["trigger_tau"],
        improved_trigger_tau=imp["trigger_tau"],
        conn_trigger_tau=conn["trigger_tau"],
        baseline_final_tau=base["tau_end"],
        improved_final_tau=imp["tau_end"],
        conn_final_tau=conn["tau_end"],
        baseline_final_ur=base["final_ur"],
        improved_final_ur=imp["final_ur"],
        conn_final_ur=conn["final_ur"],
        baseline_outcome=base["outcome"],
        improved_outcome=imp["outcome"],
        conn_outcome=conn["outcome"],
        notes="; ".join(notes),
    )

def summarize(results: List[CompareResult]) -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v10_improved_baseline ===")
    lines.append("")
    lines.append("Comparing three evolutions:")
    lines.append("- connection-driven branch law")
    lines.append("- crude first-integral baseline")
    lines.append("- improved first-integral outgoing baseline")
    lines.append("")
    for r in results:
        lines.append(
            f"- {r.label}: conn={r.conn_outcome}, improved={r.improved_outcome}, crude={r.baseline_outcome}, "
            f"trigger_tau(conn/improved/crude)=({r.conn_trigger_tau:.3f}/{r.improved_trigger_tau:.3f}/{r.baseline_trigger_tau:.3f}), "
            f"final_tau(conn/improved/crude)=({r.conn_final_tau:.3f}/{r.improved_final_tau:.3f}/{r.baseline_final_tau:.3f})"
        )
    lines.append("")
    lines.append("Interpretation:")
    lines.append("- If the improved baseline now matches connection-driven outcome, the earlier mismatch was mostly due to a weak control model.")
    lines.append("- If connection-driven remains distinct even from the improved baseline, the connection dynamics are genuinely shaping recovery.")
    lines.append("- Final tau comparison shows whether the branch-law recovery speed is method-dependent.")
    return "\n".join(lines)

def csv_table(results: List[CompareResult]) -> str:
    lines = ["label,conn_outcome,improved_outcome,crude_outcome,conn_trigger_tau,improved_trigger_tau,crude_trigger_tau,conn_final_tau,improved_final_tau,crude_final_tau,conn_final_ur,improved_final_ur,crude_final_ur,notes"]
    for r in results:
        lines.append(
            f"{r.label},{r.conn_outcome},{r.improved_outcome},{r.baseline_outcome},{r.conn_trigger_tau:.6f},{r.improved_trigger_tau:.6f},{r.baseline_trigger_tau:.6f},"
            f"{r.conn_final_tau:.6f},{r.improved_final_tau:.6f},{r.baseline_final_tau:.6f},{r.conn_final_ur:.6e},{r.improved_final_ur:.6e},{r.baseline_final_ur:.6e},\"{r.notes}\""
        )
    return "\n".join(lines)

def main():
    cases = [(1.0,1.0), (0.95,1.0), (1.0,1.25)]
    results = [compare_one(E,M) for E,M in cases]
    print(summarize(results))
    print("")
    print("--- CSV TABLE ---")
    print(csv_table(results))

if __name__ == "__main__":
    main()
