
# Branch Connection Geodesic v10 Improved Baseline

Compares:
- connection-driven branch evolution
- crude first-integral baseline
- improved first-integral outgoing baseline

using the same trigger/reset/damping concept.
