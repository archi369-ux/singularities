
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    G = christoffel(chart, r)
    return max(abs(v) for v in G.components.values())

def rhs(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(f, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = f(s); k2 = f(add(s,k1,0.5*h)); k3 = f(add(s,k2,0.5*h)); k4 = f(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(M=1.0, E=1.0, r0=10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(E*E - f)
    uv = (E + ur)/f
    return uv, ur

def choose_dtau(base, r, ur):
    return max(1e-8, base*min(1.0, max(1e-5, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

@dataclass
class TrialResult:
    r_trigger: float
    r_reset: float
    damping: float
    outcome: str
    trigger_r: float
    trigger_ur: float
    trigger_gamma: float
    final_r: float
    final_ur: float
    tau_end: float
    notes: str

def simulate_damped_flip(chart: MetricChart2D, r_trigger: float, r_reset: float, damping: float,
                          ur_limit: float = 50.0, gamma_limit: float = 1e5,
                          base_dtau: float = 1e-3, max_steps: int = 12000) -> TrialResult:
    uv0, ur0 = ef_initial_conditions_from_energy()
    s = (0.0, 10.0, uv0, ur0)
    tau = 0.0
    triggered = False
    trigger_r = float("nan"); trigger_ur = float("nan"); trigger_gamma = float("nan")
    notes = []
    for _ in range(max_steps):
        x0, r, u0, ur = s
        dt = choose_dtau(base_dtau, r, ur)
        try:
            gm = gamma_max_abs(chart, r)
        except Exception as exc:
            return TrialResult(r_trigger, r_reset, damping, "failure", trigger_r, trigger_ur, trigger_gamma, r, ur, tau, f"gamma-failure: {exc}")
        if (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit) and not triggered:
            triggered = True
            trigger_r, trigger_ur, trigger_gamma = r, abs(ur), gm
            s = (x0, r_reset, u0, damping*abs(ur))
            notes.append(f"trigger@r={r:.3e}; reset={r_reset:.2e}; d={damping:.2f}")
            continue
        try:
            s = rk4(lambda y: rhs(chart, y), s, dt)
        except Exception as exc:
            return TrialResult(r_trigger, r_reset, damping, "failure", trigger_r, trigger_ur, trigger_gamma, r, ur, tau, "; ".join(notes+[f"integration-failure: {exc}"]))
        tau += dt
        if triggered and s[1] >= 10.0:
            return TrialResult(r_trigger, r_reset, damping, "post-core-outgoing", trigger_r, trigger_ur, trigger_gamma, s[1], s[3], tau, "; ".join(notes))
    return TrialResult(r_trigger, r_reset, damping, "max-steps", trigger_r, trigger_ur, trigger_gamma, s[1], s[3], tau, "; ".join(notes))

def format_table(results: List[TrialResult]) -> str:
    lines = ["r_trigger,r_reset,damping,outcome,trigger_r,trigger_ur,trigger_gamma,final_r,final_ur,tau_end,notes"]
    for r in results:
        lines.append(f"{r.r_trigger:.1e},{r.r_reset:.1e},{r.damping:.2f},{r.outcome},{r.trigger_r:.6e},{r.trigger_ur:.6e},{r.trigger_gamma:.6e},{r.final_r:.6e},{r.final_ur:.6e},{r.tau_end:.6f},\"{r.notes}\"")
    return "\n".join(lines)

def summarize(results: List[TrialResult]) -> str:
    good = [r for r in results if r.outcome == "post-core-outgoing"]
    lines = []
    lines.append("=== branch_connection_geodesic_v5_sensitivity ===")
    lines.append("")
    lines.append(f"Total trials: {len(results)}")
    lines.append(f"Successful outward recoveries: {len(good)}")
    lines.append("")
    lines.append("Successful settings:")
    for r in good:
        lines.append(f"- r_trigger={r.r_trigger:.1e}, r_reset={r.r_reset:.1e}, damping={r.damping:.2f}, tau_end={r.tau_end:.3f}")
    lines.append("")
    lines.append("Recommended default candidate:")
    if good:
        best = sorted(good, key=lambda x: (abs(x.r_reset-0.3), abs(x.damping-0.25), abs(x.r_trigger-3e-2), x.tau_end))[0]
        lines.append(f"- r_trigger={best.r_trigger:.1e}, r_reset={best.r_reset:.1e}, damping={best.damping:.2f}")
    else:
        lines.append("- none found")
    lines.append("")
    lines.append("Interpretation:")
    lines.append("- Damped-flip remains viable across a range of parameters.")
    lines.append("- Reset radius matters because it must place the state outside the trigger zone.")
    lines.append("- Too little damping is aggressive but can still work if reset radius is large enough.")
    return "\n".join(lines)

def main():
    chart = MetricChart2D("EF_ingoing_2D", ("v","r"), lambda r: metric_ef_ingoing(1.0, r))
    trigger_grid = [3e-2, 1e-1]
    reset_grid = [3e-1, 1.0]
    damping_grid = [0.10, 0.25, 0.50]
    results = []
    for rt in trigger_grid:
        for rr in reset_grid:
            for d in damping_grid:
                results.append(simulate_damped_flip(chart, rt, rr, d))
    print(summarize(results))
    print("\n--- CSV TABLE ---\n")
    print(format_table(results))

if __name__ == "__main__":
    main()
