
# Branch Connection Geodesic v5 Sensitivity

This bundle studies the sensitivity of the damped-flip continuation law over:
- trigger radius
- reset radius
- damping factor

It reports:
- successful outward recoveries
- a CSV table of all trials
- a recommended default candidate
