
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

# ============================================================
# Geometry
# ============================================================

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3, c, 2, "udd")

def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    return max(abs(v) for v in christoffel(chart, r).components.values())

# ============================================================
# Exterior geodesic model
# ============================================================

def rhs_geodesic(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(rhs, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = rhs(s); k2 = rhs(add(s,k1,0.5*h)); k3 = rhs(add(s,k2,0.5*h)); k4 = rhs(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(E: float, M: float = 1.0, r0: float = 10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(max(0.0, E*E - f))
    uv = (E + ur)/f
    return uv, ur

def choose_dtau(base, r, ur):
    return max(1e-8, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

# ============================================================
# Diagnostics
# ============================================================

def timelike_constraint(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    return g.get((0,0))*u0*u0 + 2.0*g.get((0,1))*u0*ur + g.get((1,1))*ur*ur

def killing_energy(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    return -(g.get((0,0))*u0 + g.get((0,1))*ur)

# ============================================================
# Baselines
# ============================================================

def solve_ur_from_constraint_given_u0(chart: MetricChart2D, r: float, u0: float) -> float:
    f = -chart.g_cov_fn(r).get((0,0))
    return (-1.0 + f*u0*u0)/(2.0*u0)

def make_constraint_only_reset(chart: MetricChart2D, x0: float, incoming_u0: float, r_reset: float, damping_u0: float):
    mag_u0 = max(1e-8, damping_u0 * abs(incoming_u0))
    cands = []
    for sign in (+1.0, -1.0):
        u0 = sign * mag_u0
        ur = solve_ur_from_constraint_given_u0(chart, r_reset, u0)
        cands.append((u0, ur))
    outgoing = [(u0,ur) for (u0,ur) in cands if ur > 0]
    u0, ur = sorted(outgoing, key=lambda p: (abs(p[0]), 0 if p[0] < 0 else 1))[0]
    return (x0, r_reset, u0, ur)

def manifold_outgoing_state(M: float, E_target: float, r: float):
    f = 1.0 - 2.0 * M / r
    root = math.sqrt(max(0.0, E_target*E_target - f))
    ur = root
    u0 = (E_target + ur)/f
    return u0, ur

# ============================================================
# New post-boundary state space
# S_post = (x0, r, eta, sigma)
# reconstruction map Phi -> (u0, ur)
# ============================================================

def reconstruct_uv_ur(M: float, r: float, eta: float, sigma: float) -> Tuple[float, float]:
    """
    eta tracks target energy channel.
    sigma modulates outgoing radial flow.
    ur_base = sqrt(max(0, eta^2 - f))
    ur = ur_base * exp(sigma)
    u0 solved from energy relation.
    """
    f = 1.0 - 2.0*M/r
    ur_base = math.sqrt(max(0.0, eta*eta - f))
    ur = ur_base * math.exp(sigma)
    # energy relation eta = -(g_vv u0 + g_vr ur) = f*u0 - ur
    # so u0 = (eta + ur)/f
    if abs(f) < 1e-12:
        f = 1e-12
    u0 = (eta + ur) / f
    return u0, ur

def rhs_post_boundary(M: float, r: float, eta: float, sigma: float, eta_target: float,
                      lambda_eta: float, lambda_sigma: float):
    u0, ur = reconstruct_uv_ur(M, r, eta, sigma)
    dr = ur
    dx0 = u0
    deta = -lambda_eta * (eta - eta_target)
    dsigma = -lambda_sigma * sigma
    return (dx0, dr, deta, dsigma)

def rk4_post(rhs, s, h, *args):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = rhs(*s, *args)
    k2 = rhs(*add(s,k1,0.5*h), *args)
    k3 = rhs(*add(s,k2,0.5*h), *args)
    k4 = rhs(*add(s,k3,h), *args)
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

# ============================================================
# Runner
# ============================================================

@dataclass
class Result:
    label: str
    scheme: str
    outcome: str
    trigger_tau: float
    trigger_r: float
    pre_E: float
    post_E: float
    final_E: float
    reset_jump: float
    final_E_dev: float
    max_constraint_err: float
    retriggers: int
    tau_end: float
    notes: str

def simulate_scheme(E: float, M: float, scheme: str,
                    r_trigger: float = 3e-2,
                    r_reset: float = 1.0,
                    damping_u0: float = 0.10,
                    ur_limit: float = 50.0,
                    gamma_limit: float = 1e5,
                    cooldown_duration: float = 0.5,
                    base_dtau: float = 1e-3,
                    max_steps: int = 120000) -> Result:
    chart = MetricChart2D(f"EF_ingoing_2D_M{M:.2f}", ("v","r"), lambda rr: metric_ef_ingoing(M, rr))
    uv0, ur0 = ef_initial_conditions_from_energy(E, M=M)
    s_old = (0.0, 10.0, uv0, ur0)
    s_new = None  # (x0,r,eta,sigma)
    tau = 0.0
    triggered = False
    armed = True
    cooldown_until_tau = -1.0
    retriggers = 0
    trigger_tau = float("nan")
    trigger_r = float("nan")
    pre_E = float("nan")
    post_E = float("nan")
    max_cerr = 0.0
    notes = []

    for _ in range(max_steps):
        if not triggered or scheme == "constraint_only":
            x0, r, u0, ur = s_old
        else:
            x0, r, eta, sigma = s_new
            u0, ur = reconstruct_uv_ur(M, r, eta, sigma)

        dt = choose_dtau(base_dtau, r, ur)
        gm = gamma_max_abs(chart, max(r, 1e-6))
        cerr = abs(timelike_constraint(chart, max(r, 1e-6), u0, ur) + 1.0)
        max_cerr = max(max_cerr, cerr)

        if triggered and not armed and tau >= cooldown_until_tau:
            armed = True

        fire = (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit)
        if fire and armed:
            if not triggered:
                trigger_tau = tau
                trigger_r = r
                pre_E = killing_energy(chart, max(r, 1e-6), u0, ur)
                try:
                    if scheme == "constraint_only":
                        s_old = make_constraint_only_reset(chart, x0, u0, r_reset, damping_u0)
                        post_E = killing_energy(chart, s_old[1], s_old[2], s_old[3])
                    elif scheme == "boundary_manifold":
                        u0b, urb = manifold_outgoing_state(M, pre_E, r_reset)
                        post_E = killing_energy(chart, r_reset, u0b, urb)
                        # exact energy start, sigma starts at 0
                        s_new = (x0, r_reset, pre_E, 0.0)
                    elif scheme == "post_state_space":
                        # initialize eta exactly from pre-boundary energy
                        # initialize sigma so that radial speed matches a softened outgoing seed
                        u0c, urc = make_constraint_only_reset(chart, x0, u0, r_reset, damping_u0)[2:]
                        ur_base = math.sqrt(max(1e-16, pre_E*pre_E - (1.0 - 2.0*M/r_reset)))
                        sigma0 = math.log(max(1e-12, urc) / max(1e-12, ur_base))
                        s_new = (x0, r_reset, pre_E, sigma0)
                        u0p, urp = reconstruct_uv_ur(M, r_reset, pre_E, sigma0)
                        post_E = killing_energy(chart, r_reset, u0p, urp)
                        notes.append(f"sigma0={sigma0:.6e}")
                    else:
                        raise ValueError("unknown scheme")
                except Exception as exc:
                    return Result(f"M={M:.2f},E={E:.2f}", scheme, "reset-failure", trigger_tau, trigger_r, pre_E,
                                  float("nan"), float("nan"), float("nan"), float("nan"), max_cerr, retriggers, tau,
                                  f"reset failure: {exc}")
                triggered = True
                armed = False
                cooldown_until_tau = tau + cooldown_duration
                continue
            else:
                retriggers += 1
                armed = False
                cooldown_until_tau = tau + cooldown_duration
                if retriggers > 5:
                    final_E = killing_energy(chart, max(r, 1e-6), u0, ur)
                    return Result(f"M={M:.2f},E={E:.2f}", scheme, "retrigger-loop", trigger_tau, trigger_r, pre_E,
                                  post_E, final_E, post_E-pre_E, abs(final_E-E), max_cerr, retriggers, tau,
                                  "too many retriggers")

        # advance
        if triggered and scheme in ("boundary_manifold", "post_state_space"):
            # boundary_manifold = freeze sigma at 0 and eta at pre_E
            if scheme == "boundary_manifold":
                x0, r, eta, sigma = s_new
                u0m, urm = reconstruct_uv_ur(M, r, pre_E, 0.0)
                s_new = (x0 + u0m*dt, r + urm*dt, pre_E, 0.0)
            else:
                s_new = rk4_post(rhs_post_boundary, s_new, dt, pre_E, 2.0, 3.0)
        else:
            s_old = rk4(lambda y: rhs_geodesic(chart, y), s_old, dt)

        tau += dt

        if triggered:
            if scheme == "constraint_only":
                rr = s_old[1]
            else:
                rr = s_new[1]
            if rr >= 10.0:
                if scheme == "constraint_only":
                    x0f, rf, u0f, urf = s_old
                else:
                    x0f, rf, etaf, sigmaf = s_new
                    u0f, urf = reconstruct_uv_ur(M, rf, etaf, sigmaf)
                final_E = killing_energy(chart, rf, u0f, urf)
                cerrf = abs(timelike_constraint(chart, rf, u0f, urf) + 1.0)
                max_cerr = max(max_cerr, cerrf)
                return Result(f"M={M:.2f},E={E:.2f}", scheme, "post-core-outgoing", trigger_tau, trigger_r, pre_E,
                              post_E, final_E, post_E-pre_E, abs(final_E-E), max_cerr, retriggers, tau,
                              "; ".join(notes) if notes else "ok")

    if scheme == "constraint_only":
        x0f, rf, u0f, urf = s_old
    else:
        x0f, rf, etaf, sigmaf = s_new
        u0f, urf = reconstruct_uv_ur(M, rf, etaf, sigmaf)
    final_E = killing_energy(chart, rf, u0f, urf)
    return Result(f"M={M:.2f},E={E:.2f}", scheme, "max-steps", trigger_tau, trigger_r, pre_E,
                  post_E, final_E, post_E-pre_E if math.isfinite(post_E) and math.isfinite(pre_E) else float("nan"),
                  abs(final_E-E), max_cerr, retriggers, tau, "max_steps")

def summarize(results: List[Result]) -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v26_post_boundary_state_space ===")
    lines.append("")
    lines.append("Comparing post-boundary models:")
    lines.append("- constraint_only")
    lines.append("- boundary_manifold")
    lines.append("- post_state_space")
    lines.append("")
    for r in results:
        lines.append(
            f"- {r.label} / {r.scheme}: outcome={r.outcome}, "
            f"reset_jump={r.reset_jump:.3e}, final_E_dev={r.final_E_dev:.3e}, "
            f"max_constraint_err={r.max_constraint_err:.3e}, retriggers={r.retriggers}, tau_end={r.tau_end:.3f}, notes={r.notes}"
        )
    lines.append("")
    lines.append("Interpretation:")
    lines.append("- post_state_space is the first explicit new post-boundary state model with separate energy and normalization control channels.")
    lines.append("- It is successful only if it breaks the old split better than both baselines.")
    return "\\n".join(lines)

def csv_table(results: List[Result]) -> str:
    lines = ["label,scheme,outcome,trigger_tau,trigger_r,pre_E,post_E,final_E,reset_jump,final_E_dev,max_constraint_err,retriggers,tau_end,notes"]
    for r in results:
        lines.append(
            f'{r.label},{r.scheme},{r.outcome},{r.trigger_tau:.6f},{r.trigger_r:.6e},{r.pre_E:.6e},{r.post_E:.6e},{r.final_E:.6e},'
            f'{r.reset_jump:.6e},{r.final_E_dev:.6e},{r.max_constraint_err:.6e},{r.retriggers},{r.tau_end:.6f},"{r.notes}"'
        )
    return "\\n".join(lines)

def main():
    cases = [(1.25,1.00),(1.50,1.15)]
    results = []
    for M,E in cases:
        for scheme in ("constraint_only","boundary_manifold","post_state_space"):
            results.append(simulate_scheme(E=E, M=M, scheme=scheme))
    return summarize(results) + "\\n\\n--- CSV TABLE ---\\n" + csv_table(results)

if __name__ == "__main__":
    print(main())
