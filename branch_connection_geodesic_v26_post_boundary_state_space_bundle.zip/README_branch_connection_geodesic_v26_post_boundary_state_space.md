
# Branch Connection Geodesic v26 Post-Boundary State Space

First explicit post-boundary state-space experiment.

Models compared:
- constraint_only
- boundary_manifold
- post_state_space

post_state_space uses:
- eta: energy-control channel
- sigma: normalization/radial modulation channel

It reconstructs effective (u^v, u^r) from (r, eta, sigma) instead of evolving the old velocity state directly.
