
# Branch Connection Geodesic v27 Boundary Manifold Re-Audit

Purpose:
re-audit the strong recent boundary_manifold result against the constraint_only baseline.

Focus:
- post-reset energy continuity
- post-reset normalization consistency
- stable outward recovery
- whether the earlier energy-vs-normalization split still stands
