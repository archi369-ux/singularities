
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, Tuple, List
import math

# ============================================================
# Geometry
# ============================================================

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    return max(abs(v) for v in christoffel(chart, r).components.values())

# ============================================================
# Exterior geodesic model
# ============================================================

def rhs_geodesic(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(rhs, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = rhs(s); k2 = rhs(add(s,k1,0.5*h)); k3 = rhs(add(s,k2,0.5*h)); k4 = rhs(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(E: float, M: float = 1.0, r0: float = 10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(max(0.0, E*E - f))
    uv = (E + ur)/f
    return uv, ur

def choose_dtau(base, r, ur):
    return max(1e-8, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

# ============================================================
# Diagnostics
# ============================================================

def timelike_constraint(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    return g.get((0,0))*u0*u0 + 2.0*g.get((0,1))*u0*ur + g.get((1,1))*ur*ur

def killing_energy(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    return -(g.get((0,0))*u0 + g.get((0,1))*ur)

# ============================================================
# Models
# ============================================================

def solve_ur_from_constraint_given_u0(chart: MetricChart2D, r: float, u0: float) -> float:
    f = -chart.g_cov_fn(r).get((0,0))
    return (-1.0 + f*u0*u0)/(2.0*u0)

def make_constraint_only_reset(chart: MetricChart2D, x0: float, incoming_u0: float, r_reset: float, damping_u0: float):
    mag_u0 = max(1e-8, damping_u0 * abs(incoming_u0))
    cands = []
    for sign in (+1.0, -1.0):
        u0 = sign * mag_u0
        ur = solve_ur_from_constraint_given_u0(chart, r_reset, u0)
        cands.append((u0, ur))
    outgoing = [(u0,ur) for (u0,ur) in cands if ur > 0]
    u0, ur = sorted(outgoing, key=lambda p: (abs(p[0]), 0 if p[0] < 0 else 1))[0]
    return (x0, r_reset, u0, ur)

def manifold_outgoing_state(M: float, E_target: float, r: float):
    f = 1.0 - 2.0 * M / r
    root = math.sqrt(max(0.0, E_target*E_target - f))
    ur = root
    u0 = (E_target + ur)/f
    return u0, ur

# ============================================================
# Audit runner
# ============================================================

@dataclass
class AuditResult:
    label: str
    scheme: str
    outcome: str
    trigger_tau: float
    trigger_r: float
    pre_E: float
    post_E: float
    final_E: float
    reset_jump: float
    max_abs_energy_dev_after_reset: float
    mean_abs_energy_dev_after_reset: float
    max_constraint_err_after_reset: float
    mean_constraint_err_after_reset: float
    retriggers: int
    tau_end: float
    notes: str

def simulate_scheme(E: float, M: float, scheme: str,
                    r_trigger: float = 3e-2,
                    r_reset: float = 1.0,
                    damping_u0: float = 0.10,
                    ur_limit: float = 50.0,
                    gamma_limit: float = 1e5,
                    cooldown_duration: float = 0.5,
                    base_dtau: float = 1e-3,
                    max_steps: int = 120000) -> AuditResult:
    chart = MetricChart2D(f"EF_ingoing_2D_M{M:.2f}", ("v","r"), lambda rr: metric_ef_ingoing(M, rr))
    uv0, ur0 = ef_initial_conditions_from_energy(E, M=M)
    s_old = (0.0, 10.0, uv0, ur0)
    tau = 0.0
    triggered = False
    armed = True
    cooldown_until_tau = -1.0
    retriggers = 0
    trigger_tau = float("nan")
    trigger_r = float("nan")
    pre_E = float("nan")
    post_E = float("nan")
    energy_devs: List[float] = []
    c_errs: List[float] = []

    for _ in range(max_steps):
        x0, r, u0, ur = s_old
        dt = choose_dtau(base_dtau, r, ur)
        gm = gamma_max_abs(chart, max(r, 1e-6))

        if triggered:
            energy_devs.append(abs(killing_energy(chart, max(r, 1e-6), u0, ur) - pre_E))
            c_errs.append(abs(timelike_constraint(chart, max(r, 1e-6), u0, ur) + 1.0))

        if triggered and not armed and tau >= cooldown_until_tau:
            armed = True

        fire = (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit)
        if fire and armed:
            if not triggered:
                trigger_tau = tau
                trigger_r = r
                pre_E = killing_energy(chart, max(r, 1e-6), u0, ur)
                try:
                    if scheme == "constraint_only":
                        s_old = make_constraint_only_reset(chart, x0, u0, r_reset, damping_u0)
                    elif scheme == "boundary_manifold":
                        u0b, urb = manifold_outgoing_state(M, pre_E, r_reset)
                        s_old = (x0, r_reset, u0b, urb)
                    else:
                        raise ValueError("unknown scheme")
                except Exception as exc:
                    return AuditResult(f"M={M:.2f},E={E:.2f}", scheme, "reset-failure", trigger_tau, trigger_r, pre_E,
                                       float("nan"), float("nan"), float("nan"), float("nan"), float("nan"), float("nan"),
                                       float("nan"), retriggers, tau, f"reset failure: {exc}")
                post_E = killing_energy(chart, s_old[1], s_old[2], s_old[3])
                triggered = True
                armed = False
                cooldown_until_tau = tau + cooldown_duration
                energy_devs.append(abs(post_E - pre_E))
                c_errs.append(abs(timelike_constraint(chart, s_old[1], s_old[2], s_old[3]) + 1.0))
                continue
            else:
                retriggers += 1
                armed = False
                cooldown_until_tau = tau + cooldown_duration
                if retriggers > 5:
                    final_E = killing_energy(chart, s_old[1], s_old[2], s_old[3])
                    return AuditResult(
                        f"M={M:.2f},E={E:.2f}", scheme, "retrigger-loop", trigger_tau, trigger_r, pre_E,
                        post_E, final_E, post_E-pre_E, max(energy_devs) if energy_devs else float("nan"),
                        sum(energy_devs)/len(energy_devs) if energy_devs else float("nan"),
                        max(c_errs) if c_errs else float("nan"),
                        sum(c_errs)/len(c_errs) if c_errs else float("nan"),
                        retriggers, tau, "too many retriggers"
                    )

        if scheme == "boundary_manifold" and triggered:
            u0m, urm = manifold_outgoing_state(M, pre_E, r)
            s_old = (x0 + u0m*dt, r + urm*dt, u0m, urm)
        else:
            s_old = rk4(lambda y: rhs_geodesic(chart, y), s_old, dt)

        tau += dt

        if triggered and s_old[1] >= 10.0:
            final_E = killing_energy(chart, s_old[1], s_old[2], s_old[3])
            energy_devs.append(abs(final_E - pre_E))
            c_errs.append(abs(timelike_constraint(chart, s_old[1], s_old[2], s_old[3]) + 1.0))
            return AuditResult(
                f"M={M:.2f},E={E:.2f}", scheme, "post-core-outgoing", trigger_tau, trigger_r, pre_E,
                post_E, final_E, post_E-pre_E, max(energy_devs), sum(energy_devs)/len(energy_devs),
                max(c_errs), sum(c_errs)/len(c_errs), retriggers, tau, "ok"
            )

    final_E = killing_energy(chart, s_old[1], s_old[2], s_old[3])
    return AuditResult(
        f"M={M:.2f},E={E:.2f}", scheme, "max-steps", trigger_tau, trigger_r, pre_E,
        post_E, final_E, post_E-pre_E if math.isfinite(post_E) and math.isfinite(pre_E) else float("nan"),
        max(energy_devs) if energy_devs else float("nan"),
        sum(energy_devs)/len(energy_devs) if energy_devs else float("nan"),
        max(c_errs) if c_errs else float("nan"),
        sum(c_errs)/len(c_errs) if c_errs else float("nan"),
        retriggers, tau, "max_steps"
    )

def summarize(results: List[AuditResult]) -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v27_boundary_manifold_reaudit ===")
    lines.append("")
    lines.append("Goal:")
    lines.append("Re-audit the boundary_manifold model against the constraint_only baseline.")
    lines.append("This checks whether the strong recent boundary_manifold result is real or an implementation artifact.")
    lines.append("")
    for r in results:
        lines.append(
            f"- {r.label} / {r.scheme}: outcome={r.outcome}, "
            f"reset_jump={r.reset_jump:.3e}, "
            f"max|E-E_pre|_after={r.max_abs_energy_dev_after_reset:.3e}, "
            f"mean|E-E_pre|_after={r.mean_abs_energy_dev_after_reset:.3e}, "
            f"max_constraint_err_after={r.max_constraint_err_after_reset:.3e}, "
            f"mean_constraint_err_after={r.mean_constraint_err_after_reset:.3e}, "
            f"retriggers={r.retriggers}, tau_end={r.tau_end:.3f}"
        )
    lines.append("")
    lines.append("Audit question:")
    lines.append("- If boundary_manifold keeps both energy and normalization small here, then earlier claims of a hard energy-vs-normalization split need revision.")
    lines.append("- If not, the old split stands.")
    return "\n".join(lines)

def csv_table(results: List[AuditResult]) -> str:
    lines = ["label,scheme,outcome,trigger_tau,trigger_r,pre_E,post_E,final_E,reset_jump,max_abs_energy_dev_after_reset,mean_abs_energy_dev_after_reset,max_constraint_err_after_reset,mean_constraint_err_after_reset,retriggers,tau_end,notes"]
    for r in results:
        lines.append(
            f'{r.label},{r.scheme},{r.outcome},{r.trigger_tau:.6f},{r.trigger_r:.6e},{r.pre_E:.6e},{r.post_E:.6e},{r.final_E:.6e},{r.reset_jump:.6e},'
            f'{r.max_abs_energy_dev_after_reset:.6e},{r.mean_abs_energy_dev_after_reset:.6e},{r.max_constraint_err_after_reset:.6e},{r.mean_constraint_err_after_reset:.6e},{r.retriggers},{r.tau_end:.6f},"{r.notes}"'
        )
    return "\n".join(lines)

def main():
    cases = [(1.25,1.00),(1.50,1.15),(1.00,1.00)]
    results = []
    for M,E in cases:
        for scheme in ("constraint_only","boundary_manifold"):
            results.append(simulate_scheme(E=E, M=M, scheme=scheme))
    return summarize(results) + "\n\n--- CSV TABLE ---\n" + csv_table(results)

if __name__ == "__main__":
    print(main())
