
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    G = christoffel(chart, r)
    return max(abs(v) for v in G.components.values())

def rhs_geodesic(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(rhs, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = rhs(s); k2 = rhs(add(s,k1,0.5*h)); k3 = rhs(add(s,k2,0.5*h)); k4 = rhs(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(E: float, M: float = 1.0, r0: float = 10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(max(0.0, E*E - f))
    uv = (E + ur)/f if abs(f) > 1e-14 else 1.0/(E + math.sqrt(max(0.0, E*E - f)))
    return uv, ur

def choose_dtau(base, r, ur):
    return max(1e-8, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

def timelike_constraint(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    return g.get((0,0))*u0*u0 + g.get((0,1))*u0*ur + g.get((1,0))*ur*u0 + g.get((1,1))*ur*ur

def killing_energy(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    return -(g.get((0,0))*u0 + g.get((0,1))*ur)

def solve_ur_from_constraint_given_u0(chart: MetricChart2D, r: float, u0: float) -> float:
    if abs(u0) < 1e-14:
        raise ValueError("u0 too small")
    g = chart.g_cov_fn(r)
    f = -g.get((0,0))
    return (-1.0 + f*u0*u0)/(2.0*u0)

def make_constraint_only_reset(chart: MetricChart2D, x0: float, incoming_u0: float, r_reset: float, damping_u0: float):
    mag_u0 = max(1e-8, damping_u0 * abs(incoming_u0))
    cands = []
    for sign in (+1.0, -1.0):
        u0 = sign * mag_u0
        ur = solve_ur_from_constraint_given_u0(chart, r_reset, u0)
        cands.append((u0, ur))
    outgoing = [(u0,ur) for (u0,ur) in cands if ur > 0]
    if outgoing:
        outgoing.sort(key=lambda p: (abs(p[0]), 0 if p[0] < 0 else 1))
        u0, ur = outgoing[0]
    else:
        u0, ur = max(cands, key=lambda p: p[1])
    return (x0, r_reset, u0, ur)

def make_double_constraint_reset(chart: MetricChart2D, x0: float, E_target: float, r_reset: float):
    g = chart.g_cov_fn(r_reset)
    f = -g.get((0,0))
    disc = E_target*E_target - f
    if disc < 0:
        raise ValueError(f"no real outgoing branch, disc={disc}")
    root = math.sqrt(disc)
    u0 = (E_target + root)/f if abs(f) > 1e-14 else 1.0/(E_target - root + 1e-14)
    ur = +root
    return (x0, r_reset, u0, ur)

def manifold_outgoing_state(M: float, E_target: float, r: float):
    f = 1.0 - 2.0 * M / r
    disc = E_target*E_target - f
    if disc < 0:
        raise ValueError(f"no outgoing manifold state at r={r}, disc={disc}")
    ur = math.sqrt(disc)
    u0 = (E_target + ur)/f if abs(f) > 1e-14 else 1.0/(E_target - ur + 1e-14)
    return u0, ur

@dataclass
class BoundaryModelResult:
    label: str
    scheme: str
    outcome: str
    trigger_tau: float
    trigger_r: float
    pre_E: float
    post_E: float
    final_E: float
    reset_jump: float
    final_E_dev: float
    max_constraint_err: float
    retriggers: int
    tau_end: float
    notes: str

def simulate_scheme(E: float, M: float, scheme: str,
                    r_trigger: float = 3e-2,
                    r_reset: float = 1.0,
                    damping_u0: float = 0.10,
                    ur_limit: float = 50.0,
                    gamma_limit: float = 1e5,
                    cooldown_duration: float = 0.5,
                    base_dtau: float = 1e-3,
                    max_steps: int = 120000) -> BoundaryModelResult:
    chart = MetricChart2D(f"EF_ingoing_2D_M{M:.2f}", ("v","r"), lambda r: metric_ef_ingoing(M, r))
    uv0, ur0 = ef_initial_conditions_from_energy(E, M=M)
    s = (0.0, 10.0, uv0, ur0)
    tau = 0.0
    triggered = False
    armed = True
    cooldown_until_tau = -1.0
    retriggers = 0
    trigger_tau = float("nan")
    trigger_r = float("nan")
    pre_E = float("nan")
    post_E = float("nan")
    max_cerr = 0.0

    for _ in range(max_steps):
        x0, r, u0, ur = s
        dt = choose_dtau(base_dtau, r, ur)
        gm = gamma_max_abs(chart, r)
        cerr = abs(timelike_constraint(chart, r, u0, ur) + 1.0)
        max_cerr = max(max_cerr, cerr)

        if triggered and not armed and tau >= cooldown_until_tau:
            armed = True

        fire = (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit)
        if fire and armed:
            if not triggered:
                trigger_tau = tau
                trigger_r = r
                pre_E = killing_energy(chart, r, u0, ur)
                try:
                    if scheme == "constraint_only":
                        s = make_constraint_only_reset(chart, x0, u0, r_reset, damping_u0)
                    elif scheme == "double":
                        s = make_double_constraint_reset(chart, x0, pre_E, r_reset)
                    elif scheme == "boundary_manifold":
                        u0b, urb = manifold_outgoing_state(M, pre_E, r_reset)
                        s = (x0, r_reset, u0b, urb)
                    else:
                        raise ValueError("unknown scheme")
                except Exception as exc:
                    return BoundaryModelResult(f"M={M:.2f},E={E:.2f}", scheme, "reset-failure",
                                               trigger_tau, trigger_r, pre_E, float("nan"), float("nan"),
                                               float("nan"), float("nan"), max_cerr, retriggers, tau,
                                               f"reset failure: {exc}")
                post_E = killing_energy(chart, s[1], s[2], s[3])
                triggered = True
                armed = False
                cooldown_until_tau = tau + cooldown_duration
                continue
            else:
                retriggers += 1
                armed = False
                cooldown_until_tau = tau + cooldown_duration
                if retriggers > 5:
                    final_E = killing_energy(chart, s[1], s[2], s[3])
                    return BoundaryModelResult(f"M={M:.2f},E={E:.2f}", scheme, "retrigger-loop",
                                               trigger_tau, trigger_r, pre_E, post_E, final_E,
                                               post_E-pre_E, abs(final_E-E), max_cerr, retriggers, tau,
                                               "too many retriggers")

        if scheme == "boundary_manifold" and triggered:
            try:
                u0m, urm = manifold_outgoing_state(M, pre_E, r)
            except Exception as exc:
                return BoundaryModelResult(f"M={M:.2f},E={E:.2f}", scheme, "manifold-failure",
                                           trigger_tau, trigger_r, pre_E, post_E, float("nan"),
                                           post_E-pre_E, float("nan"), max_cerr, retriggers, tau,
                                           f"manifold failure: {exc}")
            s = (x0 + u0m*dt, r + urm*dt, u0m, urm)
        else:
            s = rk4(lambda y: rhs_geodesic(chart, y), s, dt)

        tau += dt
        if triggered and s[1] >= 10.0:
            final_E = killing_energy(chart, s[1], s[2], s[3])
            cerr = abs(timelike_constraint(chart, s[1], s[2], s[3]) + 1.0)
            max_cerr = max(max_cerr, cerr)
            return BoundaryModelResult(f"M={M:.2f},E={E:.2f}", scheme, "post-core-outgoing",
                                       trigger_tau, trigger_r, pre_E, post_E, final_E,
                                       post_E-pre_E, abs(final_E-E), max_cerr, retriggers, tau, "ok")

    final_E = killing_energy(chart, s[1], s[2], s[3])
    return BoundaryModelResult(f"M={M:.2f},E={E:.2f}", scheme, "max-steps",
                               trigger_tau, trigger_r, pre_E, post_E, final_E,
                               post_E-pre_E if math.isfinite(post_E) and math.isfinite(pre_E) else float("nan"),
                               abs(final_E-E), max_cerr, retriggers, tau, "max_steps")

def summarize(results: List[BoundaryModelResult]) -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v24_boundary_manifold_model ===")
    lines.append("")
    lines.append("Comparing post-boundary descriptions:")
    lines.append("- constraint_only reset + same geodesic ODE")
    lines.append("- double reset + same geodesic ODE")
    lines.append("- boundary_manifold: double-consistent reset + distinct outgoing manifold evolution")
    lines.append("")
    for r in results:
        lines.append(
            f"- {r.label} / {r.scheme}: outcome={r.outcome}, "
            f"reset_jump={r.reset_jump:.3e}, final_E_dev={r.final_E_dev:.3e}, "
            f"max_constraint_err={r.max_constraint_err:.3e}, retriggers={r.retriggers}, tau_end={r.tau_end:.3f}, notes={r.notes}"
        )
    lines.append("")
    lines.append("Interpretation:")
    lines.append("- This is the first test where the outgoing side is treated as a genuinely different post-boundary state model.")
    lines.append("- If boundary_manifold works, then the obstruction may come from forcing the outgoing side back into the same geodesic state evolution variables.")
    lines.append("- If it fails too, the boundary problem is deeper than the ODE handoff alone.")
    return "\n".join(lines)

def csv_table(results: List[BoundaryModelResult]) -> str:
    lines = ["label,scheme,outcome,trigger_tau,trigger_r,pre_E,post_E,final_E,reset_jump,final_E_dev,max_constraint_err,retriggers,tau_end,notes"]
    for r in results:
        lines.append(
            f'{r.label},{r.scheme},{r.outcome},{r.trigger_tau:.6f},{r.trigger_r:.6e},{r.pre_E:.6e},{r.post_E:.6e},{r.final_E:.6e},'
            f'{r.reset_jump:.6e},{r.final_E_dev:.6e},{r.max_constraint_err:.6e},{r.retriggers},{r.tau_end:.6f},"{r.notes}"'
        )
    return "\n".join(lines)

def main():
    cases = [(1.25,1.00),(1.50,1.15)]
    results = []
    for M,E in cases:
        for scheme in ("constraint_only","double","boundary_manifold"):
            results.append(simulate_scheme(E=E, M=M, scheme=scheme))
    return summarize(results) + "\n\n--- CSV TABLE ---\n" + csv_table(results)

if __name__ == "__main__":
    print(main())
