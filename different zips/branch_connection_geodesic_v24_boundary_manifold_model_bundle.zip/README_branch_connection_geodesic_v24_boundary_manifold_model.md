
# Branch Connection Geodesic v24 Boundary Manifold Model

Tests a genuinely different post-boundary description.

Schemes:
- constraint_only reset + same geodesic ODE
- double reset + same geodesic ODE
- boundary_manifold:
  - reset onto the outgoing energy/normalization manifold
  - evolve on that manifold directly instead of reusing the same post-reset geodesic state evolution
