
# Branch Connection Geodesic v2 (Core-Safe RK)

This bundle patches the connection-driven geodesic integrator with core-safe event handling.

## What changed

The RK integrator now:
- checks for likely core crossing
- searches for the largest safe positive-radius substep
- lands on the exact core event before invalid RK stages evaluate `r <= 0`
- then applies continuation law:
  - terminate
  - reflect
  - reemit

## Run

```bash
python branch_connection_geodesic_v2_core_safe.py
```
