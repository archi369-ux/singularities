
# Branch Connection Geodesic v9 Baseline Comparison

Compares:
- connection-driven branch evolution
- first-integral-based baseline branch evolution

using the same trigger/reset/damping concept on matched initial conditions.
