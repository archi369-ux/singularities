
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple, Union
import math


@dataclass(frozen=True)
class Guard:
    atoms: Tuple[Tuple[str, str, float], ...] = field(default_factory=tuple)

    def __and__(self, other: "Guard") -> Optional["Guard"]:
        merged = list(self.atoms) + list(other.atoms)
        normalized: Dict[str, Dict[str, float]] = {}
        for var, op, val in merged:
            normalized.setdefault(var, {})[op] = val
        for var, ops in normalized.items():
            if "==" in ops and "!=" in ops and ops["=="] == ops["!="]:
                return None
        canonical = []
        seen = set()
        for atom in merged:
            if atom not in seen:
                seen.add(atom)
                canonical.append(atom)
        canonical.sort()
        return Guard(tuple(canonical))

    def is_true_for(self, values: Dict[str, float], tol: float = 1e-12) -> bool:
        for var, op, val in self.atoms:
            if var not in values:
                return False
            x = values[var]
            if op == "==":
                if not math.isclose(x, val, abs_tol=tol):
                    return False
            elif op == "!=":
                if math.isclose(x, val, abs_tol=tol):
                    return False
            else:
                raise ValueError(f"Unsupported guard operator: {op}")
        return True

    def __str__(self) -> str:
        if not self.atoms:
            return "TRUE"
        return " ∧ ".join(f"{v} {op} {c:g}" for v, op, c in self.atoms)


TRUE_GUARD = Guard(())


def eq_guard(var: str, value: float = 0.0) -> Guard:
    return Guard(((var, "==", value),))


def neq_guard(var: str, value: float = 0.0) -> Guard:
    return Guard(((var, "!=", value),))


@dataclass(frozen=True)
class CoreValue:
    name: str
    metadata: Dict[str, str] = field(default_factory=dict)

    def __str__(self) -> str:
        if self.metadata:
            meta = ", ".join(f"{k}={v}" for k, v in self.metadata.items())
            return f"{self.name}<{meta}>"
        return self.name


ScalarAtom = Union[float, CoreValue]


@dataclass
class BranchScalar:
    cases: List[Tuple[Guard, ScalarAtom]]

    def simplify(self) -> "BranchScalar":
        self.cases = [(g, v) for g, v in self.cases if g is not None]
        return self

    def combine(self, other: "BranchScalar", op: Callable[[ScalarAtom, ScalarAtom], ScalarAtom]) -> "BranchScalar":
        out: List[Tuple[Guard, ScalarAtom]] = []
        for g1, v1 in self.cases:
            for g2, v2 in other.cases:
                g = g1 & g2
                if g is not None:
                    out.append((g, op(v1, v2)))
        return BranchScalar(out).simplify()

    def map_values(self, fn: Callable[[ScalarAtom], ScalarAtom]) -> "BranchScalar":
        return BranchScalar([(g, fn(v)) for g, v in self.cases]).simplify()

    def evaluate(self, values: Dict[str, float]) -> ScalarAtom:
        matches = [(g, v) for g, v in self.cases if g.is_true_for(values)]
        if len(matches) != 1:
            raise ValueError(f"Expected exactly 1 matching branch for {values}, got {matches}")
        return matches[0][1]

    def pretty(self) -> str:
        lines = ["BranchScalar{"]
        for g, v in self.cases:
            lines.append(f"  [{g}] -> {v}")
        lines.append("}")
        return "\n".join(lines)


def _bin(a: ScalarAtom, b: ScalarAtom, fn: Callable[[float, float], float], opname: str) -> ScalarAtom:
    if isinstance(a, CoreValue) or isinstance(b, CoreValue):
        return CoreValue(f"{opname}({a},{b})")
    return fn(float(a), float(b))


def scalar_const(x: float) -> BranchScalar:
    return BranchScalar([(TRUE_GUARD, float(x))])


@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], ScalarAtom]
    dim: int
    variance: str = ""

    def __post_init__(self) -> None:
        for key in self.components:
            if len(key) != self.rank:
                raise ValueError(f"Component key {key} does not match rank {self.rank}")
        if self.variance and len(self.variance) != self.rank:
            raise ValueError("variance string length must equal rank")

    def get(self, idx: Tuple[int, ...]) -> ScalarAtom:
        return self.components.get(idx, 0.0)


@dataclass
class BranchTensor:
    cases: List[Tuple[Guard, Tensor]]

    def simplify(self) -> "BranchTensor":
        self.cases = [(g, t) for g, t in self.cases if g is not None]
        return self

    def pretty(self, name: str = "BT") -> str:
        lines = [f"{name} = BranchTensor{{"]
        for g, t in self.cases:
            lines.append(f"  [{g}]")
            for k in sorted(t.components):
                lines.append(f"    {k}: {t.components[k]}")
        lines.append("}")
        return "\n".join(lines)

    def refine_with(self, other: "BranchTensor", combiner: Callable[[Tensor, Tensor], Tensor]) -> "BranchTensor":
        out: List[Tuple[Guard, Tensor]] = []
        for g1, t1 in self.cases:
            for g2, t2 in other.cases:
                g = g1 & g2
                if g is not None:
                    out.append((g, combiner(t1, t2)))
        return BranchTensor(out).simplify()


def inverse_metric_2x2(t: Tensor) -> Tensor:
    if t.rank != 2 or t.dim != 2:
        raise ValueError("inverse_metric_2x2 requires a 2x2 tensor")
    a = t.get((0, 0))
    b = t.get((0, 1))
    c = t.get((1, 0))
    d = t.get((1, 1))
    if any(isinstance(x, CoreValue) for x in (a, b, c, d)):
        return Tensor(
            rank=2,
            components={(0, 0): CoreValue("GINV00"), (0, 1): CoreValue("GINV01"), (1, 0): CoreValue("GINV10"), (1, 1): CoreValue("GINV11")},
            dim=2,
            variance="uu",
        )
    det = float(a) * float(d) - float(b) * float(c)
    if det == 0:
        raise ValueError("Metric is non-invertible on this branch")
    inv = {
        (0, 0): float(d) / det,
        (0, 1): -float(b) / det,
        (1, 0): -float(c) / det,
        (1, 1): float(a) / det,
    }
    return Tensor(rank=2, components=inv, dim=2, variance="uu")


def compose_mixed_identity(g_inv: Tensor, g_cov: Tensor) -> Tensor:
    dim = g_inv.dim
    comps: Dict[Tuple[int, int], ScalarAtom] = {}
    for mu in range(dim):
        for nu in range(dim):
            total: ScalarAtom = 0.0
            for a in range(dim):
                total = _bin(total, _bin(g_inv.get((mu, a)), g_cov.get((a, nu)), lambda p, q: p * q, "MUL"), lambda p, q: p + q, "ADD")
            comps[(mu, nu)] = total
    return Tensor(rank=2, components=comps, dim=dim, variance="ud")


def fixed_guard_radial_derivative(f: Callable[[float], float], r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("Derivative near branch boundary requires separate treatment")
    return (f(r + h) - f(r - h)) / (2.0 * h)


def build_branch_minkowski_2d() -> BranchTensor:
    t = Tensor(rank=2, components={(0, 0): -1.0, (1, 1): 1.0}, dim=2, variance="dd")
    return BranchTensor([(TRUE_GUARD, t)])


def build_branch_schwarzschild_t_r(M: float = 1.0) -> BranchTensor:
    regular = Tensor(
        rank=2,
        components={(0, 0): CoreValue("EXPR", {"form": f"-(1-2*{M}/r)", "guard": "r!=0"}), (1, 1): CoreValue("EXPR", {"form": f"1/(1-2*{M}/r)", "guard": "r!=0"})},
        dim=2,
        variance="dd",
    )
    core = Tensor(
        rank=2,
        components={(0, 0): CoreValue("GCORE00", {"chart": "Schwarzschild_t_r", "reason": "r=0"}), (1, 1): CoreValue("GCORE11", {"chart": "Schwarzschild_t_r", "reason": "r=0"})},
        dim=2,
        variance="dd",
    )
    return BranchTensor([(neq_guard("r", 0.0), regular), (eq_guard("r", 0.0), core)]).simplify()


def build_branch_ef_ingoing_2d(M: float = 1.0) -> BranchTensor:
    regular = Tensor(
        rank=2,
        components={(0, 0): CoreValue("EXPR", {"form": f"-(1-2*{M}/r)", "guard": "r!=0"}), (0, 1): 1.0, (1, 0): 1.0, (1, 1): 0.0},
        dim=2,
        variance="dd",
    )
    core = Tensor(
        rank=2,
        components={(0, 0): CoreValue("EFCORE00", {"reason": "r=0"}), (0, 1): CoreValue("EFCORE01", {"reason": "r=0"}), (1, 0): CoreValue("EFCORE10", {"reason": "r=0"}), (1, 1): CoreValue("EFCORE11", {"reason": "r=0"})},
        dim=2,
        variance="dd",
    )
    return BranchTensor([(neq_guard("r", 0.0), regular), (eq_guard("r", 0.0), core)]).simplify()


def evaluate_ef_metric_numeric(M: float, r: float) -> Tensor:
    if r == 0:
        raise ValueError("core branch requires separate semantics")
    f = 1.0 - 2.0 * M / r
    return Tensor(rank=2, components={(0, 0): -f, (0, 1): 1.0, (1, 0): 1.0, (1, 1): 0.0}, dim=2, variance="dd")


def evaluate_schwarzschild_metric_numeric(M: float, r: float) -> Tensor:
    if r == 0:
        raise ValueError("core branch requires separate semantics")
    f = 1.0 - 2.0 * M / r
    if f == 0:
        raise ValueError("Schwarzschild metric coefficient diverges at horizon in this chart")
    return Tensor(rank=2, components={(0, 0): -f, (1, 1): 1.0 / f}, dim=2, variance="dd")


def tensor_matrix_string(t: Tensor, name: str) -> str:
    lines = [name]
    for i in range(t.dim):
        row = []
        for j in range(t.dim):
            row.append(f"{t.get((i,j))}")
        lines.append("  [" + ", ".join(row) + "]")
    return "\n".join(lines)


def demo_report() -> str:
    lines: List[str] = []
    lines.append("=== branch_metric_tensor_layer_v1 ===")
    lines.append("")
    lines.append("What this layer provides:")
    lines.append("- guards")
    lines.append("- branch scalars")
    lines.append("- branch tensors")
    lines.append("- branch-local metric inversion")
    lines.append("- fixed-guard derivative scaffold")
    lines.append("")

    lines.append("[Minkowski 2D branch metric]")
    lines.append(build_branch_minkowski_2d().pretty("g_mink"))
    lines.append("")

    lines.append("[Ingoing EF branch metric]")
    lines.append(build_branch_ef_ingoing_2d(M=1.0).pretty("g_ef"))
    lines.append("")

    lines.append("[Schwarzschild t-r branch metric]")
    lines.append(build_branch_schwarzschild_t_r(M=1.0).pretty("g_schw"))
    lines.append("")

    lines.append("[Numeric metric checks]")
    for r in (10.0, 2.0, 1.0):
        lines.append(f"r = {r:g}")
        try:
            ef_num = evaluate_ef_metric_numeric(1.0, r)
            ef_inv = inverse_metric_2x2(ef_num)
            ef_id = compose_mixed_identity(ef_inv, ef_num)
            lines.append(tensor_matrix_string(ef_num, "  EF covariant metric"))
            lines.append(tensor_matrix_string(ef_inv, "  EF inverse metric"))
            lines.append(tensor_matrix_string(ef_id, "  EF mixed identity g^(-1)g"))
        except Exception as exc:
            lines.append(f"  EF failure: {exc}")
        try:
            schw_num = evaluate_schwarzschild_metric_numeric(1.0, r)
            schw_inv = inverse_metric_2x2(schw_num)
            schw_id = compose_mixed_identity(schw_inv, schw_num)
            lines.append(tensor_matrix_string(schw_num, "  Schwarzschild covariant metric"))
            lines.append(tensor_matrix_string(schw_inv, "  Schwarzschild inverse metric"))
            lines.append(tensor_matrix_string(schw_id, "  Schwarzschild mixed identity g^(-1)g"))
        except Exception as exc:
            lines.append(f"  Schwarzschild failure: {exc}")
        lines.append("")

    lines.append("[Derivative scaffold]")
    try:
        deriv = fixed_guard_radial_derivative(lambda x: 1.0 - 2.0 / x, r=5.0)
        lines.append(f"d/dr (1 - 2/r) at r=5 ≈ {deriv:.12f}")
    except Exception as exc:
        lines.append(f"Derivative failure: {exc}")
    lines.append("")
    lines.append("[Assessment]")
    lines.append("- EF covariant metric stays regular at the horizon r=2M in this 2D slice.")
    lines.append("- Schwarzschild t-r chart fails at r=2M as expected for chart reasons.")
    lines.append("- Both metrics branch at r=0 only in this framework.")
    lines.append("- Metric inversion is branch-local, not global.")
    lines.append("- Inverse-dependent identities are only justified on branches where inversion exists.")
    lines.append("")
    lines.append("Next serious upgrade:")
    lines.append("- branch-aware Christoffel symbols from fixed-guard derivatives")
    lines.append("- branch-aware curvature tensors")
    lines.append("- coupling this layer to the geodesic code")
    return "\n".join(lines)


if __name__ == "__main__":
    print(demo_report())
