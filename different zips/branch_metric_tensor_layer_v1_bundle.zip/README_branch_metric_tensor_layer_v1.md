
# Branch Metric / Tensor Layer v1

This bundle is the first real branch-aware metric/tensor layer.

## Includes

- guard objects
- branch scalars
- ordinary tensors
- branch tensors
- branch-local metric inversion
- fixed-guard derivative scaffold

## Demonstrates

- Minkowski 2D metric
- Schwarzschild t-r branch metric
- ingoing EF branch metric
- metric inversion on regular branches
- why EF behaves better than Schwarzschild at the horizon
- why `r = 0` remains the true branch boundary

## Run

```bash
python branch_metric_tensor_layer_v1.py
```
