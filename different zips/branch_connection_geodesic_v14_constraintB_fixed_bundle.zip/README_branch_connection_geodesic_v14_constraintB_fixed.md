
# Branch Connection Geodesic v14 Constraint-B Fixed

Fixes the root/sign selection in constraint-preserving reset family B
and retests:

- none
- cooldown

Goal:
see whether geometric consistency, no retrigger loop, and outward recovery can coexist.
