
# Branch Connection Geodesic v1

This bundle integrates geodesics directly from Christoffel symbols.

## What changed

Earlier prototypes used first-integral shortcuts during evolution.
This version evolves motion from the connection itself:

- `dx^rho/dτ = u^rho`
- `du^rho/dτ = -Γ^rho_{μν} u^μ u^ν`

## Includes

- ingoing EF 2D connection-driven geodesic integration
- Schwarzschild t-r comparison
- exact core event detection
- continuation laws:
  - terminate
  - reflect
  - reemit
