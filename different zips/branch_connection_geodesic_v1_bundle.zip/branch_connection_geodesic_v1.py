
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def metric_schwarzschild_tr(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    if abs(f) < 1e-14:
        raise ValueError("Schwarzschild chart singular at r=2M")
    return Tensor(2, {(0,0):-f, (1,1):1.0/f}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible on this branch")
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def derivative_metric_component(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined at/near core")
    if mu == 0:
        return 0.0
    gp = chart.g_cov_fn(r + h).get((i, j))
    gm = chart.g_cov_fn(r - h).get((i, j))
    return (gp - gm) / (2.0 * h)

def christoffel_numeric(chart: MetricChart2D, r: float) -> Tensor:
    g_cov = chart.g_cov_fn(r)
    g_inv = inverse_metric_2x2(g_cov)
    comps: Dict[Tuple[int,int,int], float] = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = (
                        derivative_metric_component(chart, sigma, nu, mu, r)
                        + derivative_metric_component(chart, sigma, mu, nu, r)
                        - derivative_metric_component(chart, mu, nu, sigma, r)
                    )
                    total += g_inv.get((rho, sigma)) * inside
                comps[(rho,mu,nu)] = 0.5 * total
    return Tensor(3, comps, 2, "udd")

@dataclass
class GeodesicState:
    tau: float
    x0: float
    r: float
    u0: float
    ur: float
    note: str = ""
    def line(self, chart_name: str) -> str:
        c0 = "v" if "EF" in chart_name else "t"
        suffix = f" [{self.note}]" if self.note else ""
        return f"tau={self.tau:.6f}, {c0}={self.x0:.6f}, r={self.r:.6f}, u^{c0}={self.u0:.6f}, u^r={self.ur:.6f}{suffix}"

@dataclass
class RunResult:
    chart: str
    policy: str
    history: List[GeodesicState]
    events: List[str]
    outcome: str
    def summary(self, tail: int = 8) -> str:
        lines = [f"Chart: {self.chart}", f"Policy: {self.policy}", f"Outcome: {self.outcome}", "Events:"]
        lines.extend(f"- {e}" for e in self.events) if self.events else lines.append("- none")
        lines.append("")
        lines.append("Last states:")
        for s in self.history[-tail:]:
            lines.append(s.line(self.chart))
        return "\n".join(lines)

def geodesic_rhs(chart: MetricChart2D, state: Tuple[float,float,float,float]) -> Tuple[float,float,float,float]:
    x0, r, u0, ur = state
    G = christoffel_numeric(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu)) * vel[mu] * vel[nu]
            ar -= G.get((1,mu,nu)) * vel[mu] * vel[nu]
    return (u0, ur, a0, ar)

def rk4_step(chart: MetricChart2D, state: Tuple[float,float,float,float], dtau: float) -> Tuple[float,float,float,float]:
    def add(y, k, c):
        return tuple(yi + c*ki for yi, ki in zip(y, k))
    k1 = geodesic_rhs(chart, state)
    k2 = geodesic_rhs(chart, add(state, k1, 0.5*dtau))
    k3 = geodesic_rhs(chart, add(state, k2, 0.5*dtau))
    k4 = geodesic_rhs(chart, add(state, k3, dtau))
    return tuple(yi + (dtau/6.0)*(a + 2*b + 2*c + d) for yi, a, b, c, d in zip(state, k1, k2, k3, k4))

def detect_core_event(r: float, r_next: float, tau: float, tau_next: float, s, s_next):
    if r > 0.0 and r_next <= 0.0:
        alpha = r / (r - r_next)
        tau_hit = tau + alpha * (tau_next - tau)
        hit_state = tuple(si + alpha*(sni-si) for si, sni in zip(s, s_next))
        x0_hit, _, u0_hit, ur_hit = hit_state
        return True, tau_hit, (x0_hit, 0.0, u0_hit, ur_hit)
    return False, None, None

def simulate_geodesic_from_connection(chart: MetricChart2D, x0_0: float, r0: float, u0_0: float, ur_0: float,
                                      dtau: float = 1e-3, max_steps: int = 200000, policy: str = "terminate",
                                      epsilon: float = 1e-3, reemit_radius: float = 5e-2, recovery_radius: float = 10.0) -> RunResult:
    s = (x0_0, r0, u0_0, ur_0)
    tau = 0.0
    events: List[str] = []
    history: List[GeodesicState] = [GeodesicState(0.0, x0_0, r0, u0_0, ur_0, "start")]
    crossed_horizon = False
    had_core = False
    for _ in range(max_steps):
        x0, r, u0, ur = s
        if "Schwarzschild" in chart.name and not crossed_horizon and r <= 2.0:
            events.append("Schwarzschild chart reached horizon region; integration is no longer chart-safe.")
            return RunResult(chart.name, policy, history, events, "chart-breakdown")
        try:
            s_next = rk4_step(chart, s, dtau)
        except Exception as exc:
            return RunResult(chart.name, policy, history, events + [f"integration failure: {exc}"], "failure")
        x0n, rn, u0n, urn = s_next
        taun = tau + dtau
        if "EF" in chart.name and not crossed_horizon and rn <= 2.0:
            crossed_horizon = True
            events.append("Crossed r = 2M using Christoffel-driven integration in EF. Horizon is regular here.")
        hit, tau_hit, hit_state = detect_core_event(r, rn, tau, taun, s, s_next)
        if hit:
            x0h, rh, u0h, urh = hit_state
            history.append(GeodesicState(tau_hit, x0h, rh, u0h, urh, "exact core event"))
            events.append("Exact event detection landed on r = 0.")
            if policy == "terminate":
                events.append("Continuation law: terminate.")
                return RunResult(chart.name, policy, history, events, "core-termination")
            elif policy == "reflect":
                had_core = True
                s = (x0h, epsilon, u0h, abs(urh))
                tau = tau_hit
                history.append(GeodesicState(tau, s[0], s[1], s[2], s[3], "reflect continuation"))
                events.append("Continuation law: reflect.")
                continue
            elif policy == "reemit":
                had_core = True
                s = (x0h, reemit_radius, u0h, abs(urh))
                tau = tau_hit
                history.append(GeodesicState(tau, s[0], s[1], s[2], s[3], "reemit continuation"))
                events.append("Continuation law: reemit.")
                continue
            else:
                return RunResult(chart.name, policy, history, events + [f"unknown policy: {policy}"], "failure")
        s = s_next
        tau = taun
        history.append(GeodesicState(tau, x0n, rn, u0n, urn))
        if had_core and s[1] >= recovery_radius:
            events.append(f"Outgoing branch reached recovery radius r >= {recovery_radius:g}.")
            return RunResult(chart.name, policy, history, events, "post-core-outgoing")
    events.append("Stopped at max_steps.")
    return RunResult(chart.name, policy, history, events, "max-steps")

def ef_initial_conditions_from_energy(M: float, E: float, r0: float) -> Tuple[float, float]:
    f = 1.0 - 2.0 * M / r0
    ur = -math.sqrt(E*E - f)
    uv = (E + ur)/f if abs(f) >= 1e-14 else 1.0/(E + math.sqrt(E*E - f))
    return uv, ur

def schwarzschild_initial_conditions_from_energy(M: float, E: float, r0: float) -> Tuple[float, float]:
    f = 1.0 - 2.0 * M / r0
    ur = -math.sqrt(E*E - f)
    ut = E/f
    return ut, ur

def full_report() -> str:
    M = 1.0
    E = 1.0
    ef_chart = MetricChart2D("EF_ingoing_2D_connection_geodesic", ("v","r"), lambda r: metric_ef_ingoing(M, r))
    schw_chart = MetricChart2D("Schwarzschild_t_r_2D_connection_geodesic", ("t","r"), lambda r: metric_schwarzschild_tr(M, r))
    uv0, ur0 = ef_initial_conditions_from_energy(M, E, 10.0)
    ut0, ur0s = schwarzschild_initial_conditions_from_energy(M, E, 10.0)
    lines: List[str] = []
    lines.append("=== branch_connection_geodesic_v1 ===")
    lines.append("")
    lines.append("This version integrates geodesics from Christoffel symbols directly.")
    lines.append("No first-integral stepping is used during evolution.")
    lines.append("")
    lines.append("Initial conditions are seeded from classical energy formulas once, then evolution proceeds from:")
    lines.append("  d x^rho / dτ = u^rho")
    lines.append("  d u^rho / dτ = - Γ^rho_{mu nu} u^mu u^nu")
    lines.append("")
    for policy in ("terminate", "reflect", "reemit"):
        ef_res = simulate_geodesic_from_connection(ef_chart, 0.0, 10.0, uv0, ur0, dtau=1e-3, policy=policy)
        lines.append(f"---- EF connection-driven run: {policy} ----")
        lines.append(ef_res.summary())
        lines.append("")
    schw_res = simulate_geodesic_from_connection(schw_chart, 0.0, 10.0, ut0, ur0s, dtau=1e-3, policy="terminate")
    lines.append("---- Schwarzschild connection-driven comparison ----")
    lines.append(schw_res.summary())
    lines.append("")
    lines.append("Assessment:")
    lines.append("- EF now supports end-to-end motion from metric -> inverse metric -> Christoffel -> geodesic integration.")
    lines.append("- Horizon crossing remains regular in EF when evolution is connection-driven.")
    lines.append("- Schwarzschild chart still breaks at the horizon, which is expected and desirable as a chart diagnostic.")
    lines.append("- Core handling remains branch-based at r = 0.")
    lines.append("- Reflect remains the least ad hoc nonterminal continuation among the tested policies.")
    return "\n".join(lines)

if __name__ == "__main__":
    print(full_report())
