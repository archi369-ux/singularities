
# Branch Schwarzschild Test v2

This bundle upgrades the earlier prototype.

## Added

- exact event detection for the core branch boundary `r = 0`
- three explicit continuation laws:
  - `terminate`
  - `reflect`
  - `reemit`
- ingoing Eddington–Finkelstein chart tested first
- Schwarzschild chart kept for comparison

## Why EF first

Ingoing Eddington–Finkelstein coordinates let the infalling branch cross the horizon smoothly.
That helps isolate the true branch boundary at the core instead of confusing it with the horizon.

## Run

```bash
python branch_schwarzschild_test_v2.py
```
