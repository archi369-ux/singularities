
from __future__ import annotations

from dataclasses import dataclass
from math import isfinite, sqrt
from typing import Literal


Chart = Literal["schwarzschild", "ef_ingoing"]
Policy = Literal["terminate", "reflect", "reemit"]


@dataclass
class GeodesicState:
    tau: float
    r: float
    coord: float | None
    dr_dtau: float
    dcoord_dtau: float | None
    chart: str
    direction: str
    curvature: float | str
    note: str = ""

    def line(self) -> str:
        coord_name = "t" if self.chart == "schwarzschild" else "v"
        coord_str = "undef" if self.coord is None else f"{self.coord:.6f}"
        dcoord_str = "undef" if self.dcoord_dtau is None else f"{self.dcoord_dtau:.6f}"
        k_str = self.curvature if isinstance(self.curvature, str) else f"{self.curvature:.6f}"
        suffix = f" [{self.note}]" if self.note else ""
        return (
            f"tau={self.tau:.6f}, r={self.r:.6f}, {coord_name}={coord_str}, "
            f"dr/dtau={self.dr_dtau:.6f}, d{coord_name}/dtau={dcoord_str}, "
            f"K={k_str}, dir={self.direction}{suffix}"
        )


@dataclass
class RunResult:
    chart: str
    policy: str
    history: list[GeodesicState]
    events: list[str]
    outcome: str

    def summary(self, tail: int = 8) -> str:
        lines = [f"Chart: {self.chart}", f"Policy: {self.policy}", f"Outcome: {self.outcome}", "Events:"]
        if self.events:
            lines.extend(f"- {e}" for e in self.events)
        else:
            lines.append("- none")
        lines.append("")
        lines.append("Last states:")
        for s in self.history[-tail:]:
            lines.append(s.line())
        return "\n".join(lines)


def schwarzschild_f(M: float, r: float) -> float:
    return 1.0 - 2.0 * M / r


def kretschmann_scalar(M: float, r: float) -> float | str:
    if r == 0.0:
        return "C_K(core-branch)"
    return 48.0 * (M ** 2) / (r ** 6)


def radial_speed(M: float, E: float, r: float) -> float:
    f = schwarzschild_f(M, r)
    radicand = E * E - f
    if radicand < 0 and abs(radicand) < 1e-12:
        radicand = 0.0
    if radicand < 0:
        raise ValueError(f"Negative radicand at r={r}: {radicand}")
    return sqrt(radicand)


def coord_rate(chart: Chart, M: float, E: float, r: float, dr_dtau: float) -> float | None:
    if r <= 0.0:
        return None

    f = schwarzschild_f(M, r)

    if chart == "schwarzschild":
        if abs(f) < 1e-12:
            return None
        return E / f

    if chart == "ef_ingoing":
        # dv/dtau = (E + dr/dtau) / f
        # Stable at the horizon on the infalling branch.
        if abs(f) < 1e-12:
            if dr_dtau <= 0:
                s = radial_speed(M, E, r)
                return 1.0 / (E + s)
            return None
        return (E + dr_dtau) / f

    raise ValueError(f"Unknown chart: {chart}")


def state_from_values(
    chart: Chart,
    M: float,
    E: float,
    tau: float,
    r: float,
    coord: float | None,
    inward: bool,
    note: str = "",
) -> GeodesicState:
    s = radial_speed(M, E, r if r > 0 else 1e-30)
    dr = -s if inward else s
    dcoord = coord_rate(chart, M, E, r, dr) if r > 0 else None
    return GeodesicState(
        tau=tau,
        r=r,
        coord=coord,
        dr_dtau=dr,
        dcoord_dtau=dcoord,
        chart=chart,
        direction="in" if inward else "out",
        curvature=kretschmann_scalar(M, r),
        note=note,
    )


def advance_one_step(
    chart: Chart,
    M: float,
    E: float,
    tau: float,
    r: float,
    coord: float | None,
    inward: bool,
    dtau: float,
) -> tuple[float, float, float | None, float, float | None]:
    s = radial_speed(M, E, r)
    dr_dtau = -s if inward else s
    dcoord_dtau = coord_rate(chart, M, E, r, dr_dtau)

    tau_next = tau + dtau
    r_next = r + dr_dtau * dtau

    if coord is None or dcoord_dtau is None or not isfinite(dcoord_dtau):
        coord_next = None
    else:
        coord_next = coord + dcoord_dtau * dtau

    return tau_next, r_next, coord_next, dr_dtau, dcoord_dtau


def detect_core_event(
    tau: float,
    r: float,
    coord: float | None,
    tau_next: float,
    r_next: float,
    coord_next: float | None,
) -> tuple[bool, float | None, float | None]:
    if r > 0.0 and r_next <= 0.0:
        alpha = r / (r - r_next)
        tau_hit = tau + alpha * (tau_next - tau)
        coord_hit = None if coord is None or coord_next is None else coord + alpha * (coord_next - coord)
        return True, tau_hit, coord_hit
    return False, None, None


def simulate_branch_geodesic(
    chart: Chart = "ef_ingoing",
    M: float = 1.0,
    E: float = 1.0,
    r0: float = 10.0,
    dtau: float = 1e-3,
    max_steps: int = 2_000_000,
    policy: Policy = "terminate",
    epsilon: float = 1e-3,
    reemit_radius: float = 5e-2,
    stop_after_recovery_radius: float | None = None,
) -> RunResult:
    if M <= 0:
        raise ValueError("M must be > 0")
    if E <= 0:
        raise ValueError("E must be > 0")
    if r0 <= 2.0 * M:
        raise ValueError("Start outside the horizon for this demo")

    tau = 0.0
    r = r0
    coord = 0.0
    inward = True
    crossed_horizon = False
    had_core_event = False
    events: list[str] = []
    history: list[GeodesicState] = [state_from_values(chart, M, E, tau, r, coord, inward, note="start")]

    for _ in range(max_steps):
        tau_next, r_next, coord_next, dr_dtau, dcoord_dtau = advance_one_step(chart, M, E, tau, r, coord, inward, dtau)

        if not crossed_horizon and r_next <= 2.0 * M:
            crossed_horizon = True
            events.append("Crossed r = 2M. Horizon encountered. This is not the singular branch.")

        hit_core, tau_hit, coord_hit = detect_core_event(tau, r, coord, tau_next, r_next, coord_next)
        if hit_core:
            history.append(
                GeodesicState(
                    tau=tau_hit,
                    r=0.0,
                    coord=coord_hit,
                    dr_dtau=dr_dtau,
                    dcoord_dtau=dcoord_dtau,
                    chart=chart,
                    direction="in" if inward else "out",
                    curvature=kretschmann_scalar(M, 0.0),
                    note="exact core event",
                )
            )
            had_core_event = True
            events.append("Exact event detection landed on r = 0 branch boundary.")

            if policy == "terminate":
                events.append("Applied continuation law: terminate.")
                return RunResult(chart=chart, policy=policy, history=history, events=events, outcome="core-termination")

            if policy == "reflect":
                inward = False
                tau = tau_hit
                r = epsilon
                coord = coord_hit
                history.append(state_from_values(chart, M, E, tau, r, coord, inward, note="reflect continuation"))
                events.append("Applied continuation law: reflect. Flipped radial direction and restarted at +epsilon.")
                continue

            if policy == "reemit":
                inward = False
                tau = tau_hit
                r = reemit_radius
                coord = coord_hit
                history.append(state_from_values(chart, M, E, tau, r, coord, inward, note="reemit continuation"))
                events.append("Applied continuation law: reemit. Jumped to +reemit_radius on outgoing branch.")
                continue

            raise ValueError(f"Unknown policy: {policy}")

        tau, r, coord = tau_next, r_next, coord_next
        history.append(
            GeodesicState(
                tau=tau,
                r=r,
                coord=coord,
                dr_dtau=dr_dtau,
                dcoord_dtau=dcoord_dtau,
                chart=chart,
                direction="in" if inward else "out",
                curvature=kretschmann_scalar(M, r if r > 0 else 0.0),
            )
        )

        if had_core_event and not inward:
            target = stop_after_recovery_radius if stop_after_recovery_radius is not None else r0
            if r >= target:
                events.append(f"Outgoing continuation reached recovery radius r >= {target:g}.")
                return RunResult(chart=chart, policy=policy, history=history, events=events, outcome="post-core-outgoing")

    events.append("Stopped at max_steps.")
    return RunResult(chart=chart, policy=policy, history=history, events=events, outcome="max-steps")


def compare_policies_ef_first(M: float = 1.0, E: float = 1.0, r0: float = 10.0, dtau: float = 1e-3) -> str:
    lines: list[str] = []
    lines.append("=== Branch Schwarzschild Test v2 ===")
    lines.append("")
    lines.append("Added in this version:")
    lines.append("- event detection for exact landing on r = 0 branch boundary")
    lines.append("- three explicit continuation laws: terminate, reflect, reemit")
    lines.append("- ingoing Eddington-Finkelstein chart test first")
    lines.append("")
    lines.append("Core equations used:")
    lines.append("  (dr/dtau)^2 = E^2 - (1 - 2M/r)")
    lines.append("  Schwarzschild: dt/dtau = E / (1 - 2M/r)")
    lines.append("  Ingoing EF:    dv/dtau = (E + dr/dtau) / (1 - 2M/r)")
    lines.append("")
    lines.append("---- Ingoing Eddington-Finkelstein ----")
    for pol in ("terminate", "reflect", "reemit"):
        res = simulate_branch_geodesic(
            chart="ef_ingoing",
            M=M,
            E=E,
            r0=r0,
            dtau=dtau,
            policy=pol,
            stop_after_recovery_radius=r0,
        )
        lines.append("")
        lines.append(res.summary())
    lines.append("")
    lines.append("---- Schwarzschild coordinate comparison ----")
    res_s = simulate_branch_geodesic(
        chart="schwarzschild",
        M=M,
        E=E,
        r0=r0,
        dtau=dtau,
        policy="terminate",
    )
    lines.append(res_s.summary())
    lines.append("")
    lines.append("Stand now:")
    lines.append("- Horizon is still separated from the core branch.")
    lines.append("- EF chart stays smooth through the horizon on the infalling branch.")
    lines.append("- Core boundary is now hit by event detection instead of raw overshoot.")
    lines.append("- Continuation laws are explicit, testable, and comparable.")
    lines.append("- Kruskal is still pending.")
    return "\n".join(lines)


if __name__ == "__main__":
    print(compare_policies_ef_first())
