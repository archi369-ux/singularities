
# Branch Connection Geodesic v16 Staged Validation

Staged validation for the strongest current prototype law.

Law:
- pre-core trigger
- constraint-preserving reset family B (fixed root/sign)
- cooldown anti-retrigger

Cases:
- (M,E) = (0.75,0.95), (1.00,0.95), (1.00,1.15), (1.25,1.00)
