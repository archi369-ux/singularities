
# Branch Connection Geodesic v7 Energy Sensitivity

This bundle tests the current default branch law against multiple initial energy values.

Default law tested:
- pre-core trigger r_trigger = 3e-2
- reset radius r_reset = 1.0
- damped-flip damping = 0.10
