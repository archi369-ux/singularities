
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

# ============================================================
# Geometry
# ============================================================

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    G = christoffel(chart, r)
    return max(abs(v) for v in G.components.values())

# ============================================================
# ODE
# ============================================================

def rhs(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(f, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = f(s); k2 = f(add(s,k1,0.5*h)); k3 = f(add(s,k2,0.5*h)); k4 = f(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(E: float, M: float = 1.0, r0: float = 10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(max(0.0, E*E - f))
    uv = (E + ur)/f if abs(f) > 1e-14 else 1.0/(E + math.sqrt(max(0.0, E*E - f)))
    return uv, ur

def choose_dtau(base, r, ur):
    return max(1e-9, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

# ============================================================
# Trial
# ============================================================

@dataclass
class TrialResult:
    E: float
    outcome: str
    trigger_r: float
    trigger_ur: float
    trigger_gamma: float
    final_r: float
    final_ur: float
    tau_end: float
    retriggers: int
    notes: str

def simulate_default_law(chart: MetricChart2D, E: float,
                         r_trigger: float = 3e-2,
                         r_reset: float = 1.0,
                         damping: float = 0.10,
                         ur_limit: float = 50.0,
                         gamma_limit: float = 1e5,
                         base_dtau: float = 1e-3,
                         max_steps: int = 70000) -> TrialResult:
    uv0, ur0 = ef_initial_conditions_from_energy(E)
    s = (0.0, 10.0, uv0, ur0)
    tau = 0.0
    triggered = False
    retriggers = 0
    trigger_r = float("nan"); trigger_ur = float("nan"); trigger_gamma = float("nan")
    notes = []
    for _ in range(max_steps):
        x0, r, u0, ur = s
        dt = choose_dtau(base_dtau, r, ur)
        try:
            gm = gamma_max_abs(chart, r)
        except Exception as exc:
            return TrialResult(E, "failure", trigger_r, trigger_ur, trigger_gamma, r, ur, tau, retriggers, f"gamma-failure: {exc}")

        if (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit):
            if not triggered:
                triggered = True
                trigger_r, trigger_ur, trigger_gamma = r, abs(ur), gm
                s = (x0, r_reset, u0, damping*abs(ur))
                notes.append(f"trigger@r={r:.3e}; reset={r_reset:.2e}; d={damping:.2f}")
                continue
            else:
                retriggers += 1
                s = (x0, max(r_reset, 2*r_trigger), u0, damping*abs(ur))
                notes.append(f"retrigger@r={r:.3e}")
                if retriggers > 5:
                    return TrialResult(E, "retrigger-loop", trigger_r, trigger_ur, trigger_gamma, r, ur, tau, retriggers, "; ".join(notes))

        try:
            s = rk4(lambda y: rhs(chart, y), s, dt)
        except Exception as exc:
            return TrialResult(E, "failure", trigger_r, trigger_ur, trigger_gamma, r, ur, tau, retriggers, "; ".join(notes+[f"integration-failure: {exc}"]))

        tau += dt
        if triggered and s[1] >= 10.0:
            return TrialResult(E, "post-core-outgoing", trigger_r, trigger_ur, trigger_gamma, s[1], s[3], tau, retriggers, "; ".join(notes))
    return TrialResult(E, "max-steps", trigger_r, trigger_ur, trigger_gamma, s[1], s[3], tau, retriggers, "; ".join(notes))

# ============================================================
# Report
# ============================================================

def summarize(results: List[TrialResult]) -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v7_energy_sensitivity ===")
    lines.append("")
    lines.append("Testing the current default candidate:")
    lines.append("- pre-core trigger at r_trigger = 3e-2")
    lines.append("- reset radius r_reset = 1.0")
    lines.append("- damped-flip with damping = 0.10")
    lines.append("")
    ok = [r for r in results if r.outcome == "post-core-outgoing"]
    lines.append(f"Energy values tested: {len(results)}")
    lines.append(f"Successful outward recoveries: {len(ok)}")
    lines.append("")
    for r in results:
        lines.append(
            f"- E={r.E:.2f}: outcome={r.outcome}, trigger_r={r.trigger_r:.3e}, "
            f"trigger_|ur|={r.trigger_ur:.3e}, retriggers={r.retriggers}, "
            f"final_r={r.final_r:.3e}, final_ur={r.final_ur:.3e}, tau_end={r.tau_end:.3f}"
        )
    lines.append("")
    lines.append("Assessment:")
    lines.append("- This checks whether the default law is tied to one special energy or survives a small energy band.")
    lines.append("- Stable behavior across multiple E values is the first sign that the branch law is not just a one-point numerical artifact.")
    lines.append("- Trigger radius and trigger velocity drift with E are expected; repeated success is what matters most.")
    return "\n".join(lines)

def csv_table(results: List[TrialResult]) -> str:
    lines = ["E,outcome,trigger_r,trigger_ur,trigger_gamma,final_r,final_ur,tau_end,retriggers,notes"]
    for r in results:
        lines.append(
            f"{r.E:.2f},{r.outcome},{r.trigger_r:.6e},{r.trigger_ur:.6e},{r.trigger_gamma:.6e},"
            f"{r.final_r:.6e},{r.final_ur:.6e},{r.tau_end:.6f},{r.retriggers},\"{r.notes}\""
        )
    return "\n".join(lines)

def main():
    chart = MetricChart2D("EF_ingoing_2D", ("v","r"), lambda r: metric_ef_ingoing(1.0, r))
    energies = [0.85, 0.95, 1.00, 1.05, 1.15]
    results = [simulate_default_law(chart, E) for E in energies]
    print(summarize(results))
    print("\n--- CSV TABLE ---\n")
    print(csv_table(results))

if __name__ == "__main__":
    main()
