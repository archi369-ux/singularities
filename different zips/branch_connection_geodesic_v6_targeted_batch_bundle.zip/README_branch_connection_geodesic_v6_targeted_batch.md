
# Branch Connection Geodesic v6 Targeted Batch

Focused batch for damped-flip sensitivity with cases chosen to:
- actually reach the trigger
- complete within runtime limits
- compare reset radius and damping more meaningfully
