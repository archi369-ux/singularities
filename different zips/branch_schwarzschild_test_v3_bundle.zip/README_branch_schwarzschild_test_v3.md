
# Branch Schwarzschild Test v3

This bundle continues the GR branch test.

## Added

- stricter EF continuation analysis
- Kruskal-like coordinate re-expression of the same trajectory
- comparison of `terminate`, `reflect`, and `reemit`
- continuation consistency notes

## Important

This is still not full GR with branch-aware Einstein equations.
The dynamics are evolved in ingoing EF first.
Kruskal is used here mainly as a regularity / chart check.

## Run

```bash
python branch_schwarzschild_test_v3.py
```
