
from __future__ import annotations

from dataclasses import dataclass
from math import exp, isfinite, log, sqrt
from typing import Literal


Chart = Literal["ef_ingoing", "kruskal_like"]
Policy = Literal["terminate", "reflect", "reemit"]


@dataclass
class GeodesicState:
    tau: float
    r: float
    coord1: float | None
    coord2: float | None
    dr_dtau: float
    dcoord1_dtau: float | None
    dcoord2_dtau: float | None
    chart: str
    direction: str
    curvature: float | str
    note: str = ""

    def line(self) -> str:
        if self.chart == "ef_ingoing":
            c1n, c2n = "v", "-"
        else:
            c1n, c2n = "U", "V"

        c1 = "undef" if self.coord1 is None else f"{self.coord1:.6f}"
        dc1 = "undef" if self.dcoord1_dtau is None else f"{self.dcoord1_dtau:.6f}"

        if c2n == "-":
            c2 = "-"
            dc2 = "-"
        else:
            c2 = "undef" if self.coord2 is None else f"{self.coord2:.6f}"
            dc2 = "undef" if self.dcoord2_dtau is None else f"{self.dcoord2_dtau:.6f}"

        k_str = self.curvature if isinstance(self.curvature, str) else f"{self.curvature:.6f}"
        suffix = f" [{self.note}]" if self.note else ""

        return (
            f"tau={self.tau:.6f}, r={self.r:.6f}, {c1n}={c1}, {c2n}={c2}, "
            f"dr/dtau={self.dr_dtau:.6f}, d{c1n}/dtau={dc1}, d{c2n}/dtau={dc2}, "
            f"K={k_str}, dir={self.direction}{suffix}"
        )


@dataclass
class RunResult:
    chart: str
    policy: str
    history: list[GeodesicState]
    events: list[str]
    outcome: str

    def summary(self, tail: int = 8) -> str:
        lines = [f"Chart: {self.chart}", f"Policy: {self.policy}", f"Outcome: {self.outcome}", "Events:"]
        if self.events:
            lines.extend(f"- {e}" for e in self.events)
        else:
            lines.append("- none")
        lines.append("")
        lines.append("Last states:")
        for s in self.history[-tail:]:
            lines.append(s.line())
        return "\n".join(lines)


def f_schw(M: float, r: float) -> float:
    return 1.0 - 2.0 * M / r


def tortoise(M: float, r: float) -> float:
    if r <= 0:
        raise ValueError("r must be > 0 for tortoise coordinate")
    if abs(r - 2.0 * M) < 1e-12:
        return float("-inf")
    return r + 2.0 * M * log(abs(r / (2.0 * M) - 1.0))


def kretschmann(M: float, r: float) -> float | str:
    if r == 0.0:
        return "C_K(core-branch)"
    return 48.0 * (M ** 2) / (r ** 6)


def radial_speed(M: float, E: float, r: float) -> float:
    radicand = E * E - f_schw(M, r)
    if radicand < 0 and abs(radicand) < 1e-12:
        radicand = 0.0
    if radicand < 0:
        raise ValueError(f"Negative radicand at r={r}: {radicand}")
    return sqrt(radicand)


def dt_dtau_schwarzschild(M: float, E: float, r: float) -> float | None:
    f = f_schw(M, r)
    if abs(f) < 1e-12:
        return None
    return E / f


def dv_dtau_ef(M: float, E: float, r: float, dr_dtau: float) -> float | None:
    f = f_schw(M, r)
    if abs(f) < 1e-12:
        # horizon-stable incoming limit
        if dr_dtau <= 0:
            s = radial_speed(M, E, r)
            return 1.0 / (E + s)
        return None
    return (E + dr_dtau) / f


def kruskal_from_vr(M: float, v: float, r: float) -> tuple[float, float]:
    """
    Minimal Kruskal-like map built from advanced time v and radius r.
    Uses:
        u = v - 2 r*
        U = -exp(-u / 4M)
        V =  exp( v / 4M)

    This is enough to test horizon regularity behavior numerically.
    """
    rs = tortoise(M, r)
    u = v - 2.0 * rs
    U = -exp(-u / (4.0 * M))
    V = exp(v / (4.0 * M))
    return U, V


def kruskal_rates_from_vr(M: float, v: float, r: float, dv_dtau: float, dr_dtau: float) -> tuple[float, float]:
    rs_prime = 1.0 / f_schw(M, r)
    du_dtau = dv_dtau - 2.0 * rs_prime * dr_dtau
    U, V = kruskal_from_vr(M, v, r)
    dU_dtau = -(1.0 / (4.0 * M)) * U * du_dtau
    dV_dtau = (1.0 / (4.0 * M)) * V * dv_dtau
    return dU_dtau, dV_dtau


def make_state(
    chart: Chart,
    M: float,
    E: float,
    tau: float,
    r: float,
    coord1: float | None,
    coord2: float | None,
    inward: bool,
    note: str = "",
) -> GeodesicState:
    s = radial_speed(M, E, r if r > 0 else 1e-30)
    dr = -s if inward else s

    if chart == "ef_ingoing":
        c1rate = dv_dtau_ef(M, E, r, dr) if r > 0 else None
        return GeodesicState(
            tau=tau, r=r, coord1=coord1, coord2=None,
            dr_dtau=dr, dcoord1_dtau=c1rate, dcoord2_dtau=None,
            chart=chart, direction="in" if inward else "out",
            curvature=kretschmann(M, r), note=note
        )

    if chart == "kruskal_like":
        if coord1 is None or coord2 is None:
            raise ValueError("kruskal_like requires both U and V")
        if r <= 0:
            dU = None
            dV = None
        else:
            # coord1/coord2 are U/V, but rates computed from v and r, so recover v from V.
            v = 4.0 * M * log(coord2)
            dv = dv_dtau_ef(M, E, r, dr)
            if dv is None:
                dU = None
                dV = None
            else:
                dU, dV = kruskal_rates_from_vr(M, v, r, dv, dr)
        return GeodesicState(
            tau=tau, r=r, coord1=coord1, coord2=coord2,
            dr_dtau=dr, dcoord1_dtau=dU, dcoord2_dtau=dV,
            chart=chart, direction="in" if inward else "out",
            curvature=kretschmann(M, r), note=note
        )

    raise ValueError(f"Unknown chart: {chart}")


def detect_core_event(tau: float, r: float, tau_next: float, r_next: float) -> tuple[bool, float | None]:
    if r > 0.0 and r_next <= 0.0:
        alpha = r / (r - r_next)
        return True, tau + alpha * (tau_next - tau)
    return False, None


def simulate_ef(
    M: float = 1.0,
    E: float = 1.0,
    r0: float = 10.0,
    dtau: float = 1e-3,
    max_steps: int = 2_000_000,
    policy: Policy = "terminate",
    epsilon: float = 1e-3,
    reemit_radius: float = 5e-2,
    recovery_radius: float = 10.0,
) -> RunResult:
    tau = 0.0
    r = r0
    inward = True
    events: list[str] = []
    crossed_horizon = False

    dr0 = -radial_speed(M, E, r0)
    v = 0.0
    history = [make_state("ef_ingoing", M, E, tau, r, v, None, inward, note="start")]

    for _ in range(max_steps):
        dr = -radial_speed(M, E, r) if inward else radial_speed(M, E, r)
        dv = dv_dtau_ef(M, E, r, dr)

        tau_next = tau + dtau
        r_next = r + dr * dtau
        v_next = None if v is None or dv is None else v + dv * dtau

        if not crossed_horizon and r_next <= 2.0 * M:
            crossed_horizon = True
            events.append("Crossed r = 2M smoothly in ingoing EF. Horizon is not the core branch.")

        hit, tau_hit = detect_core_event(tau, r, tau_next, r_next)
        if hit:
            alpha = r / (r - r_next)
            v_hit = None if v is None or v_next is None else v + alpha * (v_next - v)
            history.append(make_state("ef_ingoing", M, E, tau_hit, 0.0, v_hit, None, inward, note="exact core event"))
            events.append("Exact event detection landed on r = 0.")

            if policy == "terminate":
                events.append("Continuation law: terminate.")
                return RunResult("ef_ingoing", policy, history, events, "core-termination")

            if policy == "reflect":
                inward = False
                tau = tau_hit
                r = epsilon
                v = v_hit
                history.append(make_state("ef_ingoing", M, E, tau, r, v, None, inward, note="reflect continuation"))
                events.append("Continuation law: reflect.")
                continue

            if policy == "reemit":
                inward = False
                tau = tau_hit
                r = reemit_radius
                v = v_hit
                history.append(make_state("ef_ingoing", M, E, tau, r, v, None, inward, note="reemit continuation"))
                events.append("Continuation law: reemit.")
                continue

        tau, r, v = tau_next, r_next, v_next
        history.append(make_state("ef_ingoing", M, E, tau, r, v, None, inward))

        if not inward and r >= recovery_radius:
            events.append(f"Outgoing branch reached recovery radius r >= {recovery_radius:g}.")
            return RunResult("ef_ingoing", policy, history, events, "post-core-outgoing")

    events.append("Stopped at max_steps.")
    return RunResult("ef_ingoing", policy, history, events, "max-steps")


def ef_to_kruskal_snapshot(ef_result: RunResult, M: float) -> RunResult:
    """
    Re-express the EF run in Kruskal-like coordinates where possible.
    This is a chart test, not a new dynamical solve.
    """
    converted: list[GeodesicState] = []
    events = list(ef_result.events)
    events.append("Converted EF trajectory to Kruskal-like coordinates where r > 0.")
    for s in ef_result.history:
        if s.r <= 0 or s.coord1 is None:
            converted.append(
                GeodesicState(
                    tau=s.tau, r=s.r, coord1=None, coord2=None,
                    dr_dtau=s.dr_dtau, dcoord1_dtau=None, dcoord2_dtau=None,
                    chart="kruskal_like", direction=s.direction,
                    curvature=s.curvature, note=s.note
                )
            )
            continue
        try:
            U, V = kruskal_from_vr(M, s.coord1, s.r)
            dv = s.dcoord1_dtau
            if dv is None:
                dU = dV = None
            else:
                dU, dV = kruskal_rates_from_vr(M, s.coord1, s.r, dv, s.dr_dtau)
            converted.append(
                GeodesicState(
                    tau=s.tau, r=s.r, coord1=U, coord2=V,
                    dr_dtau=s.dr_dtau, dcoord1_dtau=dU, dcoord2_dtau=dV,
                    chart="kruskal_like", direction=s.direction,
                    curvature=s.curvature, note=s.note
                )
            )
        except Exception as exc:
            converted.append(
                GeodesicState(
                    tau=s.tau, r=s.r, coord1=None, coord2=None,
                    dr_dtau=s.dr_dtau, dcoord1_dtau=None, dcoord2_dtau=None,
                    chart="kruskal_like", direction=s.direction,
                    curvature=s.curvature, note=f"kruskal-conversion-failed: {exc}"
                )
            )
    return RunResult("kruskal_like", ef_result.policy, converted, events, ef_result.outcome)


def continuity_metrics(run: RunResult) -> str:
    """
    Compare state immediately before and after the core continuation event.
    """
    idx = None
    for i, s in enumerate(run.history):
        if "exact core event" in s.note:
            idx = i
            break
    if idx is None:
        return "No core event recorded."

    lines = ["Continuation consistency check:"]
    before = run.history[idx - 1] if idx - 1 >= 0 else None
    at = run.history[idx]
    after = run.history[idx + 1] if idx + 1 < len(run.history) else None

    if before:
        lines.append(f"- pre-core radius: {before.r:.12f}")
        lines.append(f"- pre-core |dr/dtau|: {abs(before.dr_dtau):.12f}")
    lines.append(f"- core radius: {at.r:.12f}")
    lines.append(f"- core curvature tag: {at.curvature}")
    if after:
        lines.append(f"- first post-core radius: {after.r:.12f}")
        lines.append(f"- first post-core |dr/dtau|: {abs(after.dr_dtau):.12f}")
        lines.append(f"- direction switched: {'yes' if before and (before.direction != after.direction) else 'no'}")

    if run.policy == "reflect":
        lines.append("- reflect law preserves branch energy parameter E and flips radial sign only.")
    elif run.policy == "reemit":
        lines.append("- reemit law injects a finite restart radius; this is more ad hoc than reflect.")
    elif run.policy == "terminate":
        lines.append("- terminate law has no post-core continuation.")
    return "\n".join(lines)


def full_report() -> str:
    lines: list[str] = []
    lines.append("=== Branch Schwarzschild Test v3 ===")
    lines.append("")
    lines.append("Scope:")
    lines.append("- stricter EF continuation analysis")
    lines.append("- Kruskal-like re-expression of the same trajectory")
    lines.append("- compare terminate / reflect / reemit")
    lines.append("")
    lines.append("Honesty:")
    lines.append("- dynamics are still solved in EF")
    lines.append("- Kruskal here is used as a chart-regularity test, not a full independent solver")
    lines.append("- core continuation laws are explicit model choices, not derived from Einstein equations")
    lines.append("")

    for pol in ("terminate", "reflect", "reemit"):
        ef = simulate_ef(policy=pol)
        lines.append(f"---- EF run: {pol} ----")
        lines.append(ef.summary())
        lines.append("")
        lines.append(continuity_metrics(ef))
        lines.append("")
        kr = ef_to_kruskal_snapshot(ef, M=1.0)
        lines.append(f"---- Kruskal-like re-expression: {pol} ----")
        lines.append(kr.summary())
        lines.append("")

    lines.append("Stand now:")
    lines.append("- EF cleanly crosses the horizon on the infalling branch.")
    lines.append("- Kruskal-like coordinates remain regular across the horizon for the same positive-r trajectory.")
    lines.append("- The true unresolved place is still the core branch at r = 0.")
    lines.append("- Reflect is the cleanest continuation law among the three because it changes the least.")
    lines.append("- Reemit is testable but more artificial.")
    lines.append("- To go beyond this, the next step is a branch-aware metric/tensor layer or a full Kruskal dynamical solver.")
    return "\n".join(lines)


if __name__ == "__main__":
    print(full_report())
