
# Branch Connection Geodesic v29 Record State Space

First explicit post-boundary model that challenges GR velocity primacy.

Schemes compared:
- constraint_only
- boundary_manifold
- record_state_space

record_state_space:
- post-boundary state = (x0, r, R, chi)
- R = record channel
- chi = branch/control channel
- effective (u^v, u^r) are reconstructed observables
