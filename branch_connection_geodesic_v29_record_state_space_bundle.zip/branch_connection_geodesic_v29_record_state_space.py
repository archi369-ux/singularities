
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, Tuple, List
import math

EPS_R = 1e-9

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def safe_r(r: float) -> float:
    return r if r > EPS_R else EPS_R

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    r = safe_r(r)
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric_analytic(M: float, i: int, j: int, mu: int, r: float) -> float:
    r = safe_r(r)
    if mu == 0:
        return 0.0
    if i == 0 and j == 0:
        return -2.0*M/(r*r)
    return 0.0

def christoffel(M: float, chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(safe_r(r))
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric_analytic(M,sigma,nu,mu,r)+dmetric_analytic(M,sigma,mu,nu,r)-dmetric_analytic(M,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

def gamma_max_abs(M: float, chart: MetricChart2D, r: float) -> float:
    return max(abs(v) for v in christoffel(M, chart, r).components.values())

def rhs_geodesic(M: float, chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(M, chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rk4(rhs, s, h):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = rhs(s); k2 = rhs(add(s,k1,0.5*h)); k3 = rhs(add(s,k2,0.5*h)); k4 = rhs(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def rk4_param(rhs, s, h, *args):
    def add(a,b,c): return tuple(ai + c*bi for ai,bi in zip(a,b))
    k1 = rhs(s,*args); k2 = rhs(add(s,k1,0.5*h),*args); k3 = rhs(add(s,k2,0.5*h),*args); k4 = rhs(add(s,k3,h),*args)
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_initial_conditions_from_energy(E: float, M: float, r0: float=10.0):
    f = 1.0 - 2.0*M/r0
    ur = -math.sqrt(max(0.0, E*E - f))
    uv = (E + ur)/f
    return uv, ur

def choose_dtau(base, r, ur):
    r = safe_r(r)
    return max(1e-8, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

def timelike_constraint(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(safe_r(r))
    return g.get((0,0))*u0*u0 + 2.0*g.get((0,1))*u0*ur + g.get((1,1))*ur*ur

def killing_energy(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(safe_r(r))
    return -(g.get((0,0))*u0 + g.get((0,1))*ur)

def solve_ur_from_constraint_given_u0(chart: MetricChart2D, r: float, u0: float) -> float:
    f = -chart.g_cov_fn(safe_r(r)).get((0,0))
    return (-1.0 + f*u0*u0)/(2.0*u0)

def make_constraint_only_reset(chart: MetricChart2D, x0: float, incoming_u0: float, r_reset: float, damping_u0: float):
    mag = max(1e-8, damping_u0*abs(incoming_u0))
    cands = []
    for sign in (+1.0,-1.0):
        u0 = sign*mag
        ur = solve_ur_from_constraint_given_u0(chart, r_reset, u0)
        cands.append((u0,ur))
    outgoing = [(u0,ur) for (u0,ur) in cands if ur > 0]
    u0, ur = sorted(outgoing, key=lambda p: (abs(p[0]), 0 if p[0] < 0 else 1))[0]
    return (x0, safe_r(r_reset), u0, ur)

def manifold_outgoing_state(M: float, E_target: float, r: float):
    r = safe_r(r)
    f = 1.0 - 2.0*M/r
    ur = math.sqrt(max(0.0, E_target*E_target - f))
    denom = f if abs(f) > 1e-12 else 1e-12
    u0 = (E_target + ur)/denom
    return u0, ur

# New state variables (x0, r, R, chi)
def reconstruct_uv_ur(M: float, r: float, R: float, chi: float):
    r = safe_r(r)
    f = 1.0 - 2.0*M/r
    ur_base = math.sqrt(max(0.0, R*R - f))
    B = max(0.2, min(2.0, 1.0 + 0.25*chi))
    ur = ur_base * B
    denom = f if abs(f) > 1e-12 else 1e-12
    u0 = (R + ur)/denom
    return u0, ur

def rhs_record_state(state: Tuple[float,float,float,float], M: float, R_anchor: float):
    x0, r, R, chi = state
    u0, ur = reconstruct_uv_ur(M, r, R, chi)
    # Keep record anchored; damp chi toward 0 rather than scan a target each step.
    return (u0, ur, -2.0*(R - R_anchor), -3.0*chi)

@dataclass
class Result:
    label: str
    scheme: str
    outcome: str
    reset_jump: float
    final_E_dev: float
    max_constraint_err_after: float
    mean_constraint_err_after: float
    max_abs_energy_dev_after: float
    mean_abs_energy_dev_after: float
    retriggers: int
    tau_end: float
    notes: str

def simulate_scheme(E: float, M: float, scheme: str, r_trigger=3e-2, r_reset=1.0, base_dtau=1e-3, max_steps=100000):
    chart = MetricChart2D(f"EF_M{M:.2f}", ("v","r"), lambda rr: metric_ef_ingoing(M, rr))
    uv0, ur0 = ef_initial_conditions_from_energy(E, M)
    s_old = (0.0, 10.0, uv0, ur0)
    s_post = None
    tau = 0.0
    triggered = False
    pre_E = float('nan')
    post_E = float('nan')
    c_errs = []; e_errs = []
    retriggers = 0
    notes = []

    for _ in range(max_steps):
        if triggered and scheme == "record_state_space":
            x0, r, R, chi = s_post
            u0, ur = reconstruct_uv_ur(M, r, R, chi)
        else:
            x0, r, u0, ur = s_old

        if triggered:
            c_errs.append(abs(timelike_constraint(chart, r, u0, ur)+1.0))
            e_errs.append(abs(killing_energy(chart, r, u0, ur)-pre_E))

        dt = choose_dtau(base_dtau, r, ur)
        fire = (safe_r(r) <= r_trigger or abs(ur) >= 50.0 or gamma_max_abs(M, chart, r) >= 1e5)

        if fire and not triggered:
            pre_E = killing_energy(chart, r, u0, ur)
            if scheme == "constraint_only":
                s_old = make_constraint_only_reset(chart, x0, u0, r_reset, 0.10)
                post_E = killing_energy(chart, s_old[1], s_old[2], s_old[3])
            elif scheme == "boundary_manifold":
                u0b, urb = manifold_outgoing_state(M, pre_E, r_reset)
                s_old = (x0, safe_r(r_reset), u0b, urb)
                post_E = killing_energy(chart, s_old[1], s_old[2], s_old[3])
            elif scheme == "record_state_space":
                # initialize chi so B roughly matches constraint-only outgoing radial speed
                _, _, u0c, urc = make_constraint_only_reset(chart, x0, u0, r_reset, 0.10)
                urb = manifold_outgoing_state(M, pre_E, r_reset)[1]
                chi0 = 4.0*((urc/max(urb,1e-12)) - 1.0)
                chi0 = max(-3.0, min(3.0, chi0))
                s_post = (x0, safe_r(r_reset), pre_E, chi0)
                u0p, urp = reconstruct_uv_ur(M, r_reset, pre_E, chi0)
                post_E = killing_energy(chart, r_reset, u0p, urp)
                notes.append(f"chi0={chi0:.3e}")
            triggered = True
            e_errs.append(abs(post_E - pre_E))
            continue

        if triggered and scheme == "boundary_manifold":
            u0m, urm = manifold_outgoing_state(M, pre_E, r)
            s_old = (x0 + u0m*dt, safe_r(r)+urm*dt, u0m, urm)
            rr = s_old[1]
        elif triggered and scheme == "record_state_space":
            s_post = rk4_param(rhs_record_state, s_post, dt, M, pre_E)
            rr = s_post[1]
        else:
            s_old = rk4(lambda y: rhs_geodesic(M, chart, y), s_old, dt)
            rr = s_old[1]

        tau += dt
        if triggered and rr >= 10.0:
            if scheme == "record_state_space":
                x0f, rf, Rf, chif = s_post
                u0f, urf = reconstruct_uv_ur(M, rf, Rf, chif)
            else:
                x0f, rf, u0f, urf = s_old
            final_E = killing_energy(chart, rf, u0f, urf)
            c_errs.append(abs(timelike_constraint(chart, rf, u0f, urf)+1.0))
            e_errs.append(abs(final_E - pre_E))
            return Result(
                label=f"M={M:.2f},E={E:.2f}",
                scheme=scheme,
                outcome="post-core-outgoing",
                reset_jump=post_E-pre_E,
                final_E_dev=abs(final_E-E),
                max_constraint_err_after=max(c_errs) if c_errs else float('nan'),
                mean_constraint_err_after=sum(c_errs)/len(c_errs) if c_errs else float('nan'),
                max_abs_energy_dev_after=max(e_errs) if e_errs else float('nan'),
                mean_abs_energy_dev_after=sum(e_errs)/len(e_errs) if e_errs else float('nan'),
                retriggers=retriggers,
                tau_end=tau,
                notes="; ".join(notes) if notes else "ok"
            )

    # max steps
    if triggered and scheme == "record_state_space":
        x0f, rf, Rf, chif = s_post
        u0f, urf = reconstruct_uv_ur(M, rf, Rf, chif)
    else:
        x0f, rf, u0f, urf = s_old
    final_E = killing_energy(chart, rf, u0f, urf)
    return Result(
        label=f"M={M:.2f},E={E:.2f}",
        scheme=scheme,
        outcome="max-steps",
        reset_jump=post_E-pre_E if triggered else float('nan'),
        final_E_dev=abs(final_E-E),
        max_constraint_err_after=max(c_errs) if c_errs else float('nan'),
        mean_constraint_err_after=sum(c_errs)/len(c_errs) if c_errs else float('nan'),
        max_abs_energy_dev_after=max(e_errs) if e_errs else float('nan'),
        mean_abs_energy_dev_after=sum(e_errs)/len(e_errs) if e_errs else float('nan'),
        retriggers=retriggers,
        tau_end=tau,
        notes="max_steps" if triggered else "never_triggered"
    )

def summarize(results):
    lines = []
    lines.append("=== branch_connection_geodesic_v29_record_state_space ===")
    lines.append("")
    lines.append("Comparing post-boundary models:")
    lines.append("- constraint_only")
    lines.append("- boundary_manifold")
    lines.append("- record_state_space")
    lines.append("")
    for r in results:
        lines.append(
            f"- {r.label} / {r.scheme}: outcome={r.outcome}, reset_jump={r.reset_jump:.3e}, "
            f"max_constraint_err_after={r.max_constraint_err_after:.3e}, mean_constraint_err_after={r.mean_constraint_err_after:.3e}, "
            f"max|E-E_pre|_after={r.max_abs_energy_dev_after:.3e}, mean|E-E_pre|_after={r.mean_abs_energy_dev_after:.3e}, "
            f"tau_end={r.tau_end:.3f}, notes={r.notes}"
        )
    lines.append("")
    lines.append("Interpretation:")
    lines.append("- record_state_space challenges GR velocity primacy by evolving record/branch variables directly.")
    lines.append("- This reduced v1 avoids expensive stepwise target searches; it is only a first probe of the new state-space idea.")
    return "\\n".join(lines)

def csv_table(results):
    lines = ["label,scheme,outcome,reset_jump,final_E_dev,max_constraint_err_after,mean_constraint_err_after,max_abs_energy_dev_after,mean_abs_energy_dev_after,retriggers,tau_end,notes"]
    for r in results:
        lines.append(
            f'{r.label},{r.scheme},{r.outcome},{r.reset_jump:.6e},{r.final_E_dev:.6e},{r.max_constraint_err_after:.6e},{r.mean_constraint_err_after:.6e},{r.max_abs_energy_dev_after:.6e},{r.mean_abs_energy_dev_after:.6e},{r.retriggers},{r.tau_end:.6f},"{r.notes}"'
        )
    return "\\n".join(lines)

def main():
    cases = [(1.25,1.00), (1.50,1.15)]
    results = []
    for M, E in cases:
        for scheme in ("constraint_only","boundary_manifold","record_state_space"):
            results.append(simulate_scheme(E=E, M=M, scheme=scheme))
    return summarize(results) + "\\n\\n--- CSV TABLE ---\\n" + csv_table(results)

if __name__ == "__main__":
    print(main())
