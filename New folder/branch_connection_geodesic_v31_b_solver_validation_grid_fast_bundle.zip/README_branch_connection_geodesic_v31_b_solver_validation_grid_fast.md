# b_solver Validation Grid (Fast Pass)

Reduced validation pass for v31 b_solver.

Grid:
- M in {0.75, 1.25, 1.75}
- E in {0.90, 1.15, 1.30}
- schemes: constraint_only, boundary_manifold, b_solver

Note:
- b_solver used reduced admissibility-search resolution for speed
- this is a stress pass, not a final exhaustive proof
