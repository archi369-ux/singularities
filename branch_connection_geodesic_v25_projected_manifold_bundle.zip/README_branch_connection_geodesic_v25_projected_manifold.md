
# Branch Connection Geodesic v25 Projected Manifold

Adds a constraint-projected manifold evolution:

- boundary_manifold:
  evolve on the outgoing energy manifold

- projected_manifold:
  evolve on the outgoing energy manifold but re-project each step toward the
  normalization-compatible manifold while keeping energy as close as possible
