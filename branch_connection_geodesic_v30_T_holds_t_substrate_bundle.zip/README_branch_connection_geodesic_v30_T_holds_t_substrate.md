
# Branch Connection Geodesic v30 T Holds t-Substrate

Theory adjustment incorporated:

- T does not itself hold information
- T holds t-like carriers that hold it

Minimal Schwarzschild prototype:
- tE = energy-like record carrier
- tN = normalization-memory carrier

Compared schemes:
- constraint_only
- boundary_manifold
- t_substrate
