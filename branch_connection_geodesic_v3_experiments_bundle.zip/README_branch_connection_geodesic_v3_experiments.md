
# Branch Connection Geodesic v3 Experiments

Tests:
1. pre-core trigger recommendation
2. adaptive timestep / exact-ish core landing
3. variable regularization with log-radius
4. stricter pre-core trigger comparison
