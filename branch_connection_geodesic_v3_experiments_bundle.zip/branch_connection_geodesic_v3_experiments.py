
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""
    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))

@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]

def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0,0):-f, (0,1):1.0, (1,0):1.0, (1,1):0.0}, 2, "dd")

def inverse_metric_2x2(t: Tensor) -> Tensor:
    a,b,c,d = t.get((0,0)), t.get((0,1)), t.get((1,0)), t.get((1,1))
    det = a*d - b*c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0,0):d/det, (0,1):-b/det, (1,0):-c/det, (1,1):a/det}, 2, "uu")

def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r+h).get((i,j)) - chart.g_cov_fn(r-h).get((i,j))) / (2.0*h)

def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart,sigma,nu,mu,r)+dmetric(chart,sigma,mu,nu,r)-dmetric(chart,mu,nu,sigma,r)
                    total += gi.get((rho,sigma))*inside
                c[(rho,mu,nu)] = 0.5*total
    return Tensor(3,c,2,"udd")

def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    G = christoffel(chart, r)
    return max(abs(v) for v in G.components.values())

@dataclass
class GeodesicState:
    tau: float
    x0: float
    r: float
    u0: float
    ur: float
    dtau_used: float
    note: str = ""
    def line(self) -> str:
        suffix = f" [{self.note}]" if self.note else ""
        return f"tau={self.tau:.6f}, v={self.x0:.6f}, r={self.r:.6e}, u^v={self.u0:.6e}, u^r={self.ur:.6e}, dtau={self.dtau_used:.1e}{suffix}"

@dataclass
class RunResult:
    label: str
    history: List[GeodesicState]
    events: List[str]
    outcome: str
    def summary(self, tail: int = 6) -> str:
        lines = [f"Case: {self.label}", f"Outcome: {self.outcome}", "Events:"]
        lines.extend(f"- {e}" for e in self.events) if self.events else lines.append("- none")
        lines.append("")
        lines.append("Last states:")
        for s in self.history[-tail:]:
            lines.append(s.line())
        return "\\n".join(lines)

def rhs(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,r,u0,ur = s
    G = christoffel(chart, r)
    vel=[u0,ur]
    a0=0.0; ar=0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur, a0, ar)

def rhs_log(chart: MetricChart2D, s: Tuple[float,float,float,float]):
    x0,y,u0,ur = s
    r = math.exp(y)
    G = christoffel(chart, r)
    vel=[u0,ur]
    a0=0.0; ar=0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0,mu,nu))*vel[mu]*vel[nu]
            ar -= G.get((1,mu,nu))*vel[mu]*vel[nu]
    return (u0, ur/r, a0, ar)

def rk4(f, s, h):
    def add(a,b,c): return tuple(ai+c*bi for ai,bi in zip(a,b))
    k1=f(s); k2=f(add(s,k1,0.5*h)); k3=f(add(s,k2,0.5*h)); k4=f(add(s,k3,h))
    return tuple(si + (h/6.0)*(a+2*b+2*c+d) for si,a,b,c,d in zip(s,k1,k2,k3,k4))

def ef_ic(M=1.0,E=1.0,r0=10.0):
    f=1.0-2.0*M/r0
    ur=-math.sqrt(E*E-f)
    uv=(E+ur)/f
    return uv,ur

def choose_dtau(base, r, ur):
    return max(1e-9, base*min(1.0, max(1e-6, r/0.3))*min(1.0, 1.0/max(1.0, abs(ur)/5.0)))

def simulate_precore(label, chart, policy, r_core, ur_limit, gamma_limit, base_dtau=1e-3, max_steps=30000):
    uv0,ur0=ef_ic()
    s=(0.0,10.0,uv0,ur0); tau=0.0
    hist=[GeodesicState(tau,*s,base_dtau,"start")]
    events=[]; had_core=False
    for _ in range(max_steps):
        x0,r,u0,ur=s
        dt=choose_dtau(base_dtau,r,ur)
        if r <= 2.0 and not any("horizon" in e for e in events):
            events.append("horizon crossed cleanly in EF")
        try:
            gm=gamma_max_abs(chart,r)
        except Exception as exc:
            events.append(f"gamma eval failure: {exc}")
            return RunResult(label,hist,events,"failure")
        if r<=r_core or abs(ur)>=ur_limit or gm>=gamma_limit:
            why = f"trigger at r={r:.3e}, |u^r|={abs(ur):.3e}, |Gamma|max={gm:.3e}"
            events.append(why)
            hist.append(GeodesicState(tau,x0,r,u0,ur,dt,"pre-core trigger"))
            if policy=="terminate":
                events.append("terminate applied")
                return RunResult(label,hist,events,"trigger-stop")
            elif policy=="reflect":
                s=(x0,max(r_core,1e-6),u0,abs(ur)); had_core=True
                hist.append(GeodesicState(tau,*s,dt,"reflect continuation"))
                events.append("reflect applied")
                continue
            else:
                s=(x0,max(5*r_core,5e-3),u0,abs(ur)); had_core=True
                hist.append(GeodesicState(tau,*s,dt,"reemit continuation"))
                events.append("reemit applied")
                continue
        try:
            s=rk4(lambda z: rhs(chart,z), s, dt)
        except Exception as exc:
            events.append(f"integration failure: {exc}")
            return RunResult(label,hist,events,"failure")
        tau += dt
        hist.append(GeodesicState(tau,*s,dt))
        if had_core and s[1] >= 10.0:
            events.append("recovered to r>=10")
            return RunResult(label,hist,events,"post-core-outgoing")
    events.append("max_steps")
    return RunResult(label,hist,events,"max-steps")

def simulate_adaptive(label, chart, base_dtau=1e-3, max_steps=30000):
    uv0,ur0=ef_ic()
    s=(0.0,10.0,uv0,ur0); tau=0.0
    hist=[GeodesicState(tau,*s,base_dtau,"start")]
    events=[]
    for _ in range(max_steps):
        x0,r,u0,ur=s
        dt=choose_dtau(base_dtau,r,ur)
        if r <= 2.0 and not any("horizon" in e for e in events):
            events.append("horizon crossed cleanly in EF")
        rlin = r + ur*dt
        if r>0 and rlin<=0:
            alpha = r/(r-rlin)
            hist.append(GeodesicState(tau+alpha*dt, x0+alpha*u0*dt, 0.0, u0, ur, alpha*dt, "linearized core event"))
            events.append("linearized core event reached")
            return RunResult(label,hist,events,"core-event")
        try:
            s=rk4(lambda z: rhs(chart,z), s, dt)
        except Exception as exc:
            events.append(f"integration failure: {exc}")
            return RunResult(label,hist,events,"failure")
        tau += dt
        hist.append(GeodesicState(tau,*s,dt))
    events.append("max_steps")
    return RunResult(label,hist,events,"max-steps")

def simulate_log(label, chart, policy, y_core=math.log(1e-4), base_dtau=1e-4, max_steps=50000):
    uv0,ur0=ef_ic()
    s=(0.0, math.log(10.0), uv0, ur0)
    tau=0.0
    hist=[GeodesicState(tau,s[0],math.exp(s[1]),s[2],s[3],base_dtau,"start")]
    events=[]; had_core=False
    for _ in range(max_steps):
        x0,y,u0,ur=s
        r=math.exp(y)
        dt=choose_dtau(base_dtau,r,ur)
        if r <= 2.0 and not any("horizon" in e for e in events):
            events.append("horizon crossed cleanly in EF")
        if y<=y_core:
            hist.append(GeodesicState(tau,x0,r,u0,ur,dt,"log trigger"))
            events.append(f"log trigger at r={r:.3e}")
            if policy=="terminate":
                events.append("terminate applied")
                return RunResult(label,hist,events,"trigger-stop")
            elif policy=="reflect":
                s=(x0,y_core,u0,abs(ur)); had_core=True
                hist.append(GeodesicState(tau,s[0],math.exp(s[1]),s[2],s[3],dt,"reflect continuation"))
                events.append("reflect applied")
                continue
            else:
                s=(x0,math.log(5e-3),u0,abs(ur)); had_core=True
                hist.append(GeodesicState(tau,s[0],math.exp(s[1]),s[2],s[3],dt,"reemit continuation"))
                events.append("reemit applied")
                continue
        try:
            s=rk4(lambda z: rhs_log(chart,z), s, dt)
        except Exception as exc:
            events.append(f"integration failure: {exc}")
            return RunResult(label,hist,events,"failure")
        tau += dt
        hist.append(GeodesicState(tau,s[0],math.exp(s[1]),s[2],s[3],dt))
        if had_core and math.exp(s[1]) >= 10.0:
            events.append("recovered to r>=10")
            return RunResult(label,hist,events,"post-core-outgoing")
    events.append("max_steps")
    return RunResult(label,hist,events,"max-steps")

def full_report():
    chart = MetricChart2D("EF_ingoing_2D_connection_geodesic", ("v","r"), lambda r: metric_ef_ingoing(1.0,r))
    lines=[]
    lines.append("=== branch_connection_geodesic_v3_experiments ===")
    lines.append("")
    lines.append("Recommendation test and 3 serious options.")
    lines.append("")

    lines.append("---- Recommendation: pre-core trigger ----")
    for pol in ("terminate","reflect","reemit"):
        lines.append(simulate_precore(f"precore/{pol}", chart, pol, 1e-3, 50.0, 1e5).summary())
        lines.append("")

    lines.append("---- Option 1: adaptive timestep / exact-ish landing ----")
    lines.append(simulate_adaptive("adaptive-exact", chart).summary())
    lines.append("")

    lines.append("---- Option 2: variable regularization (log-radius) ----")
    for pol in ("terminate","reflect","reemit"):
        lines.append(simulate_log(f"logr/{pol}", chart, pol).summary())
        lines.append("")

    lines.append("---- Option 3: stricter pre-core trigger ----")
    for pol in ("terminate","reflect","reemit"):
        lines.append(simulate_precore(f"strict-precore/{pol}", chart, pol, 1e-4, 20.0, 1e4).summary())
        lines.append("")

    lines.append("Assessment:")
    lines.append("- Pre-core trigger is the most practical stabilizer.")
    lines.append("- Adaptive timestep alone can reach a linearized core event, but it is still approximate.")
    lines.append("- Log-radius regularization delays the blow-up and gives a clean trigger surface.")
    lines.append("- The best survivor should be carried into the next branch-law phase.")
    return "\\n".join(lines)

if __name__ == "__main__":
    print(full_report())
