
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import math

# ============================================================
# Geometry
# ============================================================

@dataclass
class Tensor:
    rank: int
    components: Dict[Tuple[int, ...], float]
    dim: int
    variance: str = ""

    def get(self, idx: Tuple[int, ...]) -> float:
        return float(self.components.get(idx, 0.0))


@dataclass
class MetricChart2D:
    name: str
    coord_names: Tuple[str, str]
    g_cov_fn: Callable[[float], Tensor]


def metric_ef_ingoing(M: float, r: float) -> Tensor:
    if r <= 0.0:
        raise ValueError("core branch reached")
    f = 1.0 - 2.0 * M / r
    return Tensor(2, {(0, 0): -f, (0, 1): 1.0, (1, 0): 1.0, (1, 1): 0.0}, 2, "dd")


def inverse_metric_2x2(t: Tensor) -> Tensor:
    a, b, c, d = t.get((0, 0)), t.get((0, 1)), t.get((1, 0)), t.get((1, 1))
    det = a * d - b * c
    if abs(det) < 1e-14:
        raise ValueError("metric non-invertible")
    return Tensor(2, {(0, 0): d / det, (0, 1): -b / det, (1, 0): -c / det, (1, 1): a / det}, 2, "uu")


def dmetric(chart: MetricChart2D, i: int, j: int, mu: int, r: float, h: float = 1e-6) -> float:
    if r <= h:
        raise ValueError("boundary derivative undefined")
    if mu == 0:
        return 0.0
    return (chart.g_cov_fn(r + h).get((i, j)) - chart.g_cov_fn(r - h).get((i, j))) / (2.0 * h)


def christoffel(chart: MetricChart2D, r: float) -> Tensor:
    g = chart.g_cov_fn(r)
    gi = inverse_metric_2x2(g)
    c = {}
    for rho in range(2):
        for mu in range(2):
            for nu in range(2):
                total = 0.0
                for sigma in range(2):
                    inside = dmetric(chart, sigma, nu, mu, r) + dmetric(chart, sigma, mu, nu, r) - dmetric(chart, mu, nu, sigma, r)
                    total += gi.get((rho, sigma)) * inside
                c[(rho, mu, nu)] = 0.5 * total
    return Tensor(3, c, 2, "udd")


def gamma_max_abs(chart: MetricChart2D, r: float) -> float:
    G = christoffel(chart, r)
    return max(abs(v) for v in G.components.values())


# ============================================================
# Dynamics
# ============================================================

def rhs(chart: MetricChart2D, s: Tuple[float, float, float, float]):
    x0, r, u0, ur = s
    G = christoffel(chart, r)
    vel = [u0, ur]
    a0 = 0.0
    ar = 0.0
    for mu in range(2):
        for nu in range(2):
            a0 -= G.get((0, mu, nu)) * vel[mu] * vel[nu]
            ar -= G.get((1, mu, nu)) * vel[mu] * vel[nu]
    return (u0, ur, a0, ar)


def rk4(f, s, h):
    def add(a, b, c):
        return tuple(ai + c * bi for ai, bi in zip(a, b))
    k1 = f(s)
    k2 = f(add(s, k1, 0.5 * h))
    k3 = f(add(s, k2, 0.5 * h))
    k4 = f(add(s, k3, h))
    return tuple(si + (h / 6.0) * (a + 2 * b + 2 * c + d) for si, a, b, c, d in zip(s, k1, k2, k3, k4))


def ef_initial_conditions_from_energy(E: float, M: float = 1.0, r0: float = 10.0):
    f = 1.0 - 2.0 * M / r0
    ur = -math.sqrt(max(0.0, E * E - f))
    uv = (E + ur) / f if abs(f) > 1e-14 else 1.0 / (E + math.sqrt(max(0.0, E * E - f)))
    return uv, ur


def choose_dtau(base, r, ur):
    return max(1e-9, base * min(1.0, max(1e-6, r / 0.3)) * min(1.0, 1.0 / max(1.0, abs(ur) / 5.0)))


# ============================================================
# Constraint helpers
# ============================================================

def timelike_constraint(chart: MetricChart2D, r: float, u0: float, ur: float) -> float:
    g = chart.g_cov_fn(r)
    return g.get((0, 0)) * u0 * u0 + g.get((0, 1)) * u0 * ur + g.get((1, 0)) * ur * u0 + g.get((1, 1)) * ur * ur


def solve_ur_from_constraint_given_u0(chart: MetricChart2D, r: float, u0: float, outgoing: bool = True) -> float:
    """
    In EF:
      -(f)u0^2 + 2 u0 ur = -1
      => ur = (-1 + f*u0^2)/(2*u0)
    """
    if abs(u0) < 1e-14:
        raise ValueError("u0 too small for constraint solve")
    g = chart.g_cov_fn(r)
    f = -g.get((0, 0))
    ur = (-1.0 + f * u0 * u0) / (2.0 * u0)
    if outgoing and ur < 0:
        ur = abs(ur)
    return ur


# ============================================================
# Reset families under test
# ============================================================

def reset_constraint_B(chart: MetricChart2D, x0: float, incoming_u0: float, incoming_ur: float, r_reset: float, damping_u0: float):
    target_u0 = max(1e-8, damping_u0 * abs(incoming_u0))
    ur_out = solve_ur_from_constraint_given_u0(chart, r_reset, target_u0, outgoing=True)
    return (x0, r_reset, target_u0, ur_out, "constraint_B")


# ============================================================
# Experiment result
# ============================================================

@dataclass
class StrategyResult:
    label: str
    outcome: str
    trigger_tau: float
    first_err: float
    mean_err: float
    max_err: float
    final_err: float
    final_ur: float
    tau_end: float
    retriggers: int
    notes: str


# ============================================================
# Simulation with anti-retrigger strategies
# ============================================================

def simulate_strategy(
    E: float,
    M: float,
    strategy: str,
    r_trigger: float = 3e-2,
    r_reset: float = 1.0,
    damping_u0: float = 0.10,
    ur_limit: float = 50.0,
    gamma_limit: float = 1e5,
    base_dtau: float = 1e-3,
    max_steps: int = 70000,
):
    chart = MetricChart2D(f"EF_ingoing_2D_M{M:.2f}", ("v", "r"), lambda r: metric_ef_ingoing(M, r))
    uv0, ur0 = ef_initial_conditions_from_energy(E, M=M)
    s = (0.0, 10.0, uv0, ur0)
    tau = 0.0
    triggered = False
    trigger_tau = float("nan")
    retriggers = 0
    after_errors: List[float] = []
    notes: List[str] = []

    # anti-retrigger controls
    cooldown_until_tau = -1.0
    rearm_radius = 2.0
    if strategy == "cooldown":
        cooldown_duration = 0.5
    else:
        cooldown_duration = 0.0
    if strategy == "far_reset":
        local_r_reset = 2.0
    else:
        local_r_reset = r_reset
    if strategy == "hysteresis":
        rearm_radius = 3.0
    else:
        rearm_radius = 2.0

    armed = True

    for _ in range(max_steps):
        x0, r, u0, ur = s
        dt = choose_dtau(base_dtau, r, ur)
        gm = gamma_max_abs(chart, r)
        c_now = timelike_constraint(chart, r, u0, ur)

        if triggered:
            after_errors.append(abs(c_now + 1.0))

        # re-arm logic
        if triggered and not armed and r >= rearm_radius and tau >= cooldown_until_tau:
            armed = True
            notes.append(f"re-armed at tau={tau:.6f}, r={r:.6e}")

        fire = (r <= r_trigger or abs(ur) >= ur_limit or gm >= gamma_limit)
        if fire and armed:
            if not triggered:
                trigger_tau = tau
                try:
                    s = reset_constraint_B(chart, x0, u0, ur, local_r_reset, damping_u0)[:4]
                except Exception as exc:
                    notes.append(f"reset failure: {exc}")
                    return StrategyResult(
                        label=f"{strategy} / M={M:.2f},E={E:.2f}",
                        outcome="reset-failure",
                        trigger_tau=trigger_tau,
                        first_err=float("nan"),
                        mean_err=float("nan"),
                        max_err=float("nan"),
                        final_err=float("nan"),
                        final_ur=ur,
                        tau_end=tau,
                        retriggers=retriggers,
                        notes="; ".join(notes),
                    )
                triggered = True
                armed = False
                cooldown_until_tau = tau + cooldown_duration
                c_reset = timelike_constraint(chart, s[1], s[2], s[3])
                after_errors.append(abs(c_reset + 1.0))
                notes.append(f"trigger at tau={tau:.6f}, r={r:.6e}, g(u,u)_reset={c_reset:.6e}")
                continue
            else:
                retriggers += 1
                notes.append(f"retrigger at tau={tau:.6f}, r={r:.6e}")
                # try re-apply same family if still armed
                try:
                    s = reset_constraint_B(chart, x0, u0, ur, local_r_reset, damping_u0)[:4]
                except Exception as exc:
                    notes.append(f"retrigger reset failure: {exc}")
                    return StrategyResult(
                        label=f"{strategy} / M={M:.2f},E={E:.2f}",
                        outcome="reset-failure",
                        trigger_tau=trigger_tau,
                        first_err=after_errors[0] if after_errors else float("nan"),
                        mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
                        max_err=max(after_errors) if after_errors else float("nan"),
                        final_err=after_errors[-1] if after_errors else float("nan"),
                        final_ur=ur,
                        tau_end=tau,
                        retriggers=retriggers,
                        notes="; ".join(notes),
                    )
                armed = False
                cooldown_until_tau = tau + cooldown_duration
                if retriggers > 5:
                    return StrategyResult(
                        label=f"{strategy} / M={M:.2f},E={E:.2f}",
                        outcome="retrigger-loop",
                        trigger_tau=trigger_tau,
                        first_err=after_errors[0] if after_errors else float("nan"),
                        mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
                        max_err=max(after_errors) if after_errors else float("nan"),
                        final_err=after_errors[-1] if after_errors else float("nan"),
                        final_ur=s[3],
                        tau_end=tau,
                        retriggers=retriggers,
                        notes="; ".join(notes),
                    )
                continue

        try:
            s = rk4(lambda y: rhs(chart, y), s, dt)
        except Exception as exc:
            notes.append(f"integration failure: {exc}")
            return StrategyResult(
                label=f"{strategy} / M={M:.2f},E={E:.2f}",
                outcome="failure",
                trigger_tau=trigger_tau,
                first_err=after_errors[0] if after_errors else float("nan"),
                mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
                max_err=max(after_errors) if after_errors else float("nan"),
                final_err=after_errors[-1] if after_errors else float("nan"),
                final_ur=s[3],
                tau_end=tau,
                retriggers=retriggers,
                notes="; ".join(notes),
            )

        tau += dt
        if triggered and s[1] >= 10.0:
            c_final = timelike_constraint(chart, s[1], s[2], s[3])
            after_errors.append(abs(c_final + 1.0))
            return StrategyResult(
                label=f"{strategy} / M={M:.2f},E={E:.2f}",
                outcome="post-core-outgoing",
                trigger_tau=trigger_tau,
                first_err=after_errors[0] if after_errors else float("nan"),
                mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
                max_err=max(after_errors) if after_errors else float("nan"),
                final_err=after_errors[-1] if after_errors else float("nan"),
                final_ur=s[3],
                tau_end=tau,
                retriggers=retriggers,
                notes="; ".join(notes),
            )

    return StrategyResult(
        label=f"{strategy} / M={M:.2f},E={E:.2f}",
        outcome="max-steps",
        trigger_tau=trigger_tau,
        first_err=after_errors[0] if after_errors else float("nan"),
        mean_err=sum(after_errors) / len(after_errors) if after_errors else float("nan"),
        max_err=max(after_errors) if after_errors else float("nan"),
        final_err=after_errors[-1] if after_errors else float("nan"),
        final_ur=s[3],
        tau_end=tau,
        retriggers=retriggers,
        notes="; ".join(notes),
    )


def summarize(results: List[StrategyResult]) -> str:
    lines = []
    lines.append("=== branch_connection_geodesic_v13_constraintB_antiretrigger ===")
    lines.append("")
    lines.append("Testing constraint-preserving reset family B with anti-retrigger strategies:")
    lines.append("- none")
    lines.append("- cooldown")
    lines.append("- hysteresis")
    lines.append("- far_reset")
    lines.append("")
    for r in results:
        lines.append(
            f"- {r.label}: outcome={r.outcome}, "
            f"first_err={r.first_err:.3e}, mean_err={r.mean_err:.3e}, max_err={r.max_err:.3e}, "
            f"final_err={r.final_err:.3e}, retriggers={r.retriggers}, final_ur={r.final_ur:.3e}"
        )
    lines.append("")
    lines.append("Interpretation:")
    lines.append("- Success requires both near-zero constraint error and no destructive retrigger loop.")
    lines.append("- Cooldown tests temporal dead-zone after reset.")
    lines.append("- Hysteresis tests geometric re-arm separation.")
    lines.append("- Far-reset tests whether moving farther into the safe region is enough.")
    return "\n".join(lines)


def csv_table(results: List[StrategyResult]) -> str:
    lines = ["label,outcome,trigger_tau,first_err,mean_err,max_err,final_err,final_ur,tau_end,retriggers,notes"]
    for r in results:
        lines.append(
            f"{r.label},{r.outcome},{r.trigger_tau:.6f},{r.first_err:.6e},{r.mean_err:.6e},{r.max_err:.6e},"
            f"{r.final_err:.6e},{r.final_ur:.6e},{r.tau_end:.6f},{r.retriggers},\"{r.notes}\""
        )
    return "\n".join(lines)


def main():
    # Focus the problematic case and one stable case
    cases = [(1.0, 1.25), (1.0, 1.0)]
    strategies = ["none", "cooldown", "hysteresis", "far_reset"]
    results: List[StrategyResult] = []
    for E, M in cases:
        for s in strategies:
            results.append(simulate_strategy(E=E, M=M, strategy=s))

    print(summarize(results))
    print("")
    print("--- CSV TABLE ---")
    print(csv_table(results))

if __name__ == "__main__":
    main()
