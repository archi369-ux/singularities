
# Branch Connection Geodesic v13 Constraint-B Anti-Retrigger

Tests the constraint-preserving reset family B with anti-retrigger strategies:

- none
- cooldown
- hysteresis
- far_reset

Goal:
find out whether geometric consistency and stable outward recovery can coexist.
